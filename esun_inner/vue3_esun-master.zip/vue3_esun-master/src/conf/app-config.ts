export const IGNORE_GLOBAL_SPINNER_URLS = [];
export const DEFAULT_DATE_FORMAT = "yyyy/MM/dd";
