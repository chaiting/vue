<template>
  <F030202SCN></F030202SCN>
</template>

<script setup lang="ts">
import F030202SCN from "@/components/f03/F030102SCN.vue";
</script>
