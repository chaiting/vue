import Vue from "vue";
import VueRouter from "vue-router";
import store from "@store";
import userProfileApi from "@api/core/user-profile-api";
import frontendAccessLogApi from "@api/core/frontend-access-log-api";

Vue.use(VueRouter);

const routes = [
  // f01 ------------------------------------------------------------------------------------------
  {
    /** 表單總覽 */
    path: "/f010101scn",
    name: "F010101SCN",
    component: () =>
      import(/* webpackChunkName: "f01" */ "@views/f01/F010101SCN.vue")
  },

  // f02 ------------------------------------------------------------------------------------------
  {
    /** 活動設定主頁 */
    path: "/f020101scn",
    name: "F020101SCN",
    component: () =>
      import(/* webpackChunkName: "f02" */ "@views/f02/F020101SCN.vue")
  },

  // f03 ------------------------------------------------------------------------------------------
  {
    /** 活動維護 */
    path: "/f030101scn",
    name: "F030101SCN",
    component: () =>
      import(/* webpackChunkName: "f03" */ "@views/f03/F030101SCN.vue")
  },

  // f04 ------------------------------------------------------------------------------------------
  {
    /** 活動進程 */
    path: "/f040101scn",
    name: "F040101SCN",
    component: () =>
      import(/* webpackChunkName: "f04" */ "@views/f04/F040101SCN.vue")
  },
  {
    /** 顧客進程 */
    path: "/f040201scn",
    name: "F040201SCN",
    component: () =>
      import(/* webpackChunkName: "f04" */ "@views/f04/F040201SCN.vue")
  },
  {
    /** 顧客回饋明細 */
    path: "/f040301scn",
    name: "F040301SCN",
    component: () =>
      import(/* webpackChunkName: "f04" */ "@views/f04/F040301SCN.vue")
  },

  // f05 ------------------------------------------------------------------------------------------
  {
    /** 點數查詢 */
    path: "/f050101scn",
    name: "F050101SCN",
    component: () =>
      import(/* webpackChunkName: "f05" */ "@views/f05/F050101SCN.vue")
  },

  // f06 ------------------------------------------------------------------------------------------
  {
    /** 群組查詢 */
    path: "/f060101scn",
    name: "F060101SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060101SCN.vue")
  },
  {
    /** 名單查詢 */
    path: "/f060201scn",
    name: "F060201SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060201SCN.vue")
  },
  {
    /** 登錄查詢 */
    path: "/f060301scn",
    name: "F060301SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060301SCN.vue")
  },
  {
    /** 特店查詢 */
    path: "/f060401scn",
    name: "F060401SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060401SCN.vue")
  },
  {
    /** 特處查詢 */
    path: "/f060501scn",
    name: "F060501SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060501SCN.vue")
  },
  {
    /** 回饋金代號查詢 */
    path: "/f060601scn",
    name: "F060601SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060601SCN.vue")
  },
  {
    /** 顧客登錄 */
    path: "/f060701scn",
    name: "F060701SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060701SCN.vue")
  },
  {
    /** 南山員工資料 */
    path: "/f060801scn",
    name: "F060801SCN",
    component: () =>
      import(/* webpackChunkName: "f06" */ "@views/f06/F060801SCN.vue")
  },

  // f07 ------------------------------------------------------------------------------------------
  {
    /** 會員機制設定 */
    path: "/f070101scn",
    name: "F070101SCN",
    component: () =>
      import(/* webpackChunkName: "f07" */ "@views/f07/F070101SCN.vue")
  },
  {
    /** 會員資訊查詢 */
    path: "/f070201scn",
    name: "F070201SCN",
    component: () =>
      import(/* webpackChunkName: "f07" */ "@views/f07/F070201SCN.vue")
  },

  // f08 ------------------------------------------------------------------------------------------
  {
    /** 優惠費率資訊查詢 */
    path: "/f080101scn",
    name: "F080101SCN",
    component: () =>
      import(/* webpackChunkName: "f08" */ "@views/f08/F080101SCN.vue")
  },
  {
    /** Ubike優惠查詢 */
    path: "/f080201scn",
    name: "F080201SCN",
    component: () =>
      import(/* webpackChunkName: "f08" */ "@views/f08/F080201SCN.vue")
  },

  // f09 ------------------------------------------------------------------------------------------
  {
    /** 活動回饋檢核資訊查詢 */
    path: "/f090101scn",
    name: "F090101SCN",
    component: () =>
      import(/* webpackChunkName: "f09" */ "@views/f09/F090101SCN.vue")
  },

  // f10 ------------------------------------------------------------------------------------------
  {
    /** 特店群組對照資料查詢 */
    path: "/f100101scn",
    name: "F100101SCN",
    component: () =>
      import(/* webpackChunkName: "f10" */ "@views/f10/F100101SCN.vue")
  },
  {
    /** 活動名單對照資料查詢 */
    path: "/f100201scn",
    name: "F100201SCN",
    component: () =>
      import(/* webpackChunkName: "f10" */ "@views/f10/F100201SCN.vue")
  },

  // Core -----------------------------------------------------------------------------------------
  {
    /** Home page */
    path: "/",
    name: "LandingPage",
    redirect: { name: "F010101SCN" }
  },
  {
    /** TODO */
    path: "/about",
    name: "About",
    component: () => import(/* webpackChunkName: "Core" */ "@views/About.vue")
  },
  {
    /** 代理人身份切換 */
    path: "/agent",
    name: "Agent",
    component: () => import(/* webpackChunkName: "Core" */ "@views/Agent.vue")
  },
  {
    /** 500 Server Internal Server Error */
    path: "/error",
    name: "UnknownError",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/UnknownError.vue")
  },
  {
    /** 403 Forbidden */
    path: "/forbidden",
    name: "Forbidden",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/Forbidden.vue")
  },
  {
    /** User Profile not found */
    path: "/user_profile_not_found",
    name: "UserProfileNotFound",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/UserProfileNotFound.vue")
  },
  {
    /** Page not found */
    path: "*",
    name: "NotFound",
    component: () =>
      import(/* webpackChunkName: "Core" */ "@views/NotFound.vue")
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.VUE_APP_PUBLIC_PATH,
  routes
});

router.beforeEach((to, from, next) => {
  // 1. 如果到下列頁面，直接放行 -----------------------------------------------------------------------------------------------
  if (
    to.name === "NotFound" ||
    to.name === "Forbidden" ||
    to.name === "UnknownError" ||
    to.name === "UserProfileNotFound"
  ) {
    next();
    return;
  }

  // 2. 如果是正式環境且要去代理人身份切換頁面，直接導到存取被拒頁 ----------------------------------------------------------------
  if (process.env.NODE_ENV === "prod" && to.name === "Agent") {
    router.push("/forbidden");
    return;
  }

  // 3. 如果已經登入過，發送一個request到server端記錄Access Log ----------------------------------------------------------------
  if (store.state.userProfile.optUserProfile.adAccount) {
    frontendAccessLogApi
      .doSaveFrontendAccessLog({
        resourceUri: to.path,
        resourceType: "M" // M: Menu類
      })
      .finally(() => {
        next();
        return;
      });
  }

  // 4. 如果尚未取得基本資料，發送一個request跟server端取得，並放入store裡 -------------------------------------------------------
  if (!store.state.userProfile.optUserProfile.adAccount) {
    userProfileApi.doFetchLoginUserProfile().then(userProfile => {
      if (userProfile && userProfile.adAccount) {
        store.dispatch("doStoredUserProfile", userProfile);
        next();
      } else {
        store.dispatch("doCleanUserProfile");
        router.push("/user_profile_not_found");
      }
    });
  }
});

export default router;
