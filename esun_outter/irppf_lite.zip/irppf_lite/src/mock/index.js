import f01Init from "@mock/f01";
// import f02Init from "@mock/f02";
// import f03Init from "@mock/f03";
// import f04Init from "@mock/f04";
// import f05Init from "@mock/f05";
/**
 *
 */
export default function(mock) {
  f01Init(mock);
  // f02Init(mock);
  // f03Init(mock);
  // f04Init(mock);
  // f05Init(mock);
}
