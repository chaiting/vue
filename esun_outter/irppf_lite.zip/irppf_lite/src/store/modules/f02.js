import { getField, updateField } from "vuex-map-fields";
import { concat, cloneDeep, find, filter, forEach, map, remove } from "lodash";
import uidApi from "@api/common/act/uid-api";
import f020103Api from "@api/f02/f020103-api";
import f020104Api from "@api/f02/f020104-api";
import f020105Api from "@api/f02/f020105-api";
import f020106Api from "@api/f02/f020106-api";

const state = {
  /**
   * 通用參數
   */
  f02010301: {
    activityType: "FA", // 活動類型代碼, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=343, FA: 滿額活動
    activityId: "", // 活動代碼, Ref IRPP.TB_ACTIVITY.ACTIVITY_ID
    activityNm: "", // 活動名稱
    formId: "", // 表單號碼
    grpNm: "", // 提案/主辦單位名稱
    creatorNm: "", // 建檔人員名稱
    creatorEmpNo: "", // 建檔人員員工編號, Ref DATAASYNC.TB_USER.EMP_NO
    proposeNo: "", // 提案單號
    budgetNo: "", // 預算編號
    budgetAmount: 0, // 預算金額(元)
    productType: "C", // 適用卡片種類, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=344, C: 信用卡
    statusCd: "", // 活動狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=345
    startDate: "", // 活動起日(yyyy/MM/dd)
    endDate: "", // 活動迄日(yyyy/MM/dd)
    content: "", // 活動內容
    notice: "" // 注意事項
  },
  /**
   * 規則參數
   */
  f02010401: {
    ruleInfoList: [], // 規則資訊清單
    ruleQuestGroupList: [], // 規則題目群組清單
    ruleQuestList: [], // 規則題目清單
    ruleAnswerList: [] // 規則答案清單
  },
  /**
   * 題目及答案資訊清單(規則+活動)
   */
  questAnsList: [],
  /**
   * 暫存規則資訊
   */
  tmpRuleInfo: {
    activityId: "", // 活動代碼, Ref IRPP.TB_ACTIVITY.ACTIVITY_ID
    ruleId: "", // 規則代碼, Ref IRPP.TB_RULE.RULE_ID
    ruleNm: "", // 規則名稱
    priority: null // 回饋優先序(數值愈大愈優先)
  },
  /**
   * 已點擊確認之規則代碼清單
   */
  checkedRuleIds: new Set()
};
const getters = {
  getField
};
const actions = {
  // 1. 活動通用參數 -----------------------------------------------------------------------------------------------------
  /**
   * 重置通用參數設定值
   * @param {*} commit
   */
  doResetCommonParam({ commit }) {
    commit("doResetCommonParam");
  },
  /**
   * 依據活動代碼，取得活動基本參數資訊
   * @param {*} commit
   * @param {*} payload 查詢條件
   */
  async doGetActivityInfo({ commit }, payload) {
    let result = await f020103Api.doGetActivityInfo(payload);
    commit("doUpdActivityInfo", result);
  },

  // 2. 規則參數 ---------------------------------------------------------------------------------------------------------
  /**
   * 依據活動代碼或活動類型代碼，查詢規則參數
   * @param {*} commit
   * @param {*} payload  查詢條件
   */
  async doGetRuleParam({ commit }, payload) {
    let result = await f020104Api.doGetRuleParam(payload);
    commit("doUpdRuleParam", result);
  },
  /**
   * 依據活動代碼查詢欲引入之規則參數
   * @param {*} commit
   * @param {*} payload  查詢條件
   */
  async doGetImportedRuleParam({ commit }, payload) {
    let result = await f020106Api.doGetImportedRuleParam(payload);
    commit("doUpdRuleParam", result);
  },
  /**
   * 新增規則
   * @param {*} commit
   */
  async doAddRule({ commit }) {
    // 1. 取得規則代碼並更新暫存規則資訊 -----------------------------------------------------------------------------------
    let ruleId = await uidApi.getNextSnowFlakeId();
    commit("doUpdTmpRuleInfo", {
      activityId: state.f02010301.activityId,
      ruleId
    });

    // 2. 複製規則題目清單並置換規則代碼後存放至題目及答案資訊清單(規則+活動) -------------------------------------------------
    let ruleQuestList = map(state.f02010401.ruleQuestList, question => {
      let ruleQuest = cloneDeep(question);
      ruleQuest.ruleId = ruleId;
      return ruleQuest;
    });
    commit("doAddQuestAnsList", ruleQuestList);
  },
  /**
   * 複製規則
   * @param {*} commit
   * @param {*} payload 規則代碼
   */
  async doCloneRule({ commit }, payload) {
    // 1. 取得規則代碼並更新暫存規則資訊 -----------------------------------------------------------------------------------
    let ruleId = await uidApi.getNextSnowFlakeId();
    commit("doUpdTmpRuleInfo", {
      activityId: state.f02010301.activityId,
      ruleId
    });

    // 2. 以規則代碼為條件，過濾規則答案清單，置換規則代碼後存放至題目及答案資訊清單(規則+活動) ---------------------------------
    let ruleAnswerList = map(
      filter(
        state.f02010401.ruleAnswerList,
        ruleAnswer => ruleAnswer.ruleId === payload.ruleId
      ),
      answer => {
        let ruleAnswer = cloneDeep(answer);
        ruleAnswer.ruleId = ruleId;
        return ruleAnswer;
      }
    );
    commit("doAddQuestAnsList", ruleAnswerList);
  },
  /**
   * 顯示規則
   * @param {*} commit
   * @param {*} payload 規則代碼
   */
  doShowRule({ commit }, payload) {
    // 1. 更新暫存規則資訊 -------------------------------------------------------------------------------------------------
    commit(
      "doUpdTmpRuleInfo",
      find(
        state.f02010401.ruleInfoList,
        ruleInfo => payload.ruleId === ruleInfo.ruleId
      )
    );

    // 2. 以規則代碼為條件，過濾規則答案清單後存放至題目及答案資訊清單(規則+活動) -----------------------------------------------
    let ruleAnswerList = map(
      filter(
        state.f02010401.ruleAnswerList,
        ruleAnswer => ruleAnswer.ruleId === payload.ruleId
      ),
      answer => {
        return cloneDeep(answer);
      }
    );
    commit("doAddQuestAnsList", ruleAnswerList);
  },
  /**
   * 刪除規則
   * @param {*} commit
   * @param {*} payload 規則代碼
   */
  doDelRule({ commit }, payload) {
    // 1. 排除被刪除的規則後更新規則資訊清單 ---------------------------------------------------------------------------------
    let ruleInfoList = filter(
      state.f02010401.ruleInfoList,
      ruleInfo => ruleInfo.ruleId !== payload.ruleId
    );
    commit("doUpdRuleInfoList", ruleInfoList);

    // 2. 排除被刪除的規則答案後更新規則答案清單 -----------------------------------------------------------------------------
    let ruleAnswerList = filter(
      state.f02010401.ruleAnswerList,
      ruleAnswer => ruleAnswer.ruleId !== payload.ruleId
    );
    commit("doUpdRuleAnswerList", ruleAnswerList);
  },
  /**
   * 規則異動確認
   * @param {*} commit
   */
  doConfirmRule({ commit }) {
    commit("doAddCheckedRuleIds", state.tmpRuleInfo.ruleId); // 新增已點擊確認之規則代碼
    commit("doMergeRuleInfoList"); // 合併規則資訊清單
    commit("doMergeRuleAnswerList"); // 合併規則答案清單
    commit("doClearTmpRuleInfo"); // 清空暫存規則資訊

    // 依題目群組類型清空題目及答案資訊清單
    commit("doClearQuestAnsListByType", {
      grpType: "R" // R: 規則參數群組
    });
  },
  /**
   * 取消新增或編輯規則參數
   * @param {*} commit
   */
  doCancelRule({ commit }) {
    commit("doClearTmpRuleInfo"); // 清空暫存規則資訊

    // 依題目群組類型清空題目及答案資訊清單
    commit("doClearQuestAnsListByType", {
      grpType: "R" // R: 規則參數群組
    });
  },
  /**
   * 清空規則參數
   * @param {*} commit
   */
  doClearRuleParam({ commit }) {
    commit("doClearRuleParam");
  },

  // 3. 活動參數 ---------------------------------------------------------------------------------------------------------
  /**
   * 清空活動參數
   * @param {*} commit
   */
  doClearActivityParam({ commit }) {
    commit("doClearQuestAnsListByType", {
      grpType: "A" // A: 活動參數群組
    });
  },
  /**
   * 依據活動代碼或活動類型代碼，查詢活動參數
   * @param {*} commit
   * @param {*} payload 查詢條件
   */
  async doGetActivityParam({ commit }, payload) {
    let result = await f020105Api.doGetActivityParam(payload);
    commit("doClearQuestAnsListByType", {
      grpType: "A" // A: 活動參數群組
    });
    commit("doAddQuestAnsList", result.questions);
  },

  // 4. 規則參數、活動參數 -----------------------------------------------------------------------------------------------
  /**
   * 更新答案
   * @param {*} commit
   * @param {*} payload
   */
  doUpdAnswer({ commit }, payload) {
    commit("doUpdAnswer", payload);
  },

  // 5. 共用 ----------------------------------------------------------------------------------------------------------
  /**
   * 清空所有活動參數
   * @param {*} commit
   */
  doClearAllParam({ commit }) {
    commit("doResetCommonParam");
    commit("doClearRuleParam");
    commit("doClearCheckedRuleIds");
    commit("doClearQuestAnsListByType", {
      grpType: "A" // A: 活動參數群組
    });
  }
};
const mutations = {
  updateField,
  // 1. 活動通用參數 -----------------------------------------------------------------------------------------------------
  /**
   * 重置通用參數設定值
   * @param {*} state
   */
  doResetCommonParam(state) {
    let f02010301 = state.f02010301;
    f02010301.activityType = "FA"; // 活動類型代碼, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=343, FA: 滿額活動
    f02010301.activityId = ""; // 活動代碼, Ref IRPP.TB_ACTIVITY.ACTIVITY_ID
    f02010301.activityNm = ""; // 適活動名稱
    f02010301.formId = ""; // 表單號碼
    f02010301.grpNm = ""; // 提案/主辦單位名稱
    f02010301.creatorNm = ""; // 建檔人員名稱
    f02010301.creatorEmpNo = ""; // 建檔人員員工編號, Ref DATAASYNC.TB_USER.EMP_NO
    f02010301.proposeNo = ""; // 提案單號
    f02010301.budgetNo = ""; // 預算金額(元)
    f02010301.budgetAmount = 0; // 預算金額(元)
    f02010301.productType = "C"; // 適用卡片種類, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=344, C: 信用卡
    f02010301.statusCd = ""; // 活動狀態, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=345
    f02010301.startDate = ""; // 活動起始日(yyyy/MM/dd)
    f02010301.endDate = ""; // 活動結束日(yyyy/MM/dd)
    f02010301.content = ""; // 活動內容
    f02010301.notice = ""; // 注意事項
  },
  /**
   * 更新活動基本參數資訊
   * @param {*} state
   * @param {*} payload 活動基本參數資訊
   */
  doUpdActivityInfo(state, payload) {
    state.f02010301 = payload;
  },

  // 2. 規則參數 ---------------------------------------------------------------------------------------------------------
  /**
   * 更新規則參數
   * @param {*} state
   * @param {*} payload 規則參數
   */
  doUpdRuleParam(state, payload) {
    state.f02010401 = payload;
  },
  /**
   * 更新暫存規則資訊
   * @param {*} state
   * @param {*} payload 暫存規則資訊
   */
  doUpdTmpRuleInfo(state, payload) {
    state.tmpRuleInfo = { ...state.tmpRuleInfo, ...payload };
  },
  /**
   * 更新規則資訊清單
   * @param {*} state
   * @param {*} payload 規則資訊清單
   */
  doUpdRuleInfoList(state, payload) {
    state.f02010401.ruleInfoList = payload;
  },
  /**
   * 合併規則資訊清單
   * @param {*} state
   */
  doMergeRuleInfoList(state) {
    // 1. 依據規則代碼，先將規則資訊清單裡符合規則代碼的規則移除 -------------------------------------------------------------
    remove(
      state.f02010401.ruleInfoList,
      ruleInfo => ruleInfo.ruleId === state.tmpRuleInfo.ruleId
    );

    // 2. 再將暫存的規則加入規則資訊清單 -----------------------------------------------------------------------------------
    state.f02010401.ruleInfoList.push(state.tmpRuleInfo);
  },
  /**
   * 更新規則答案清單
   * @param {*} state
   * @param {*} payload 規則答案清單
   */
  doUpdRuleAnswerList(state, payload) {
    state.f02010401.ruleAnswerList = payload;
  },
  /**
   * 合併規則答案清單
   * @param {*} state
   */
  doMergeRuleAnswerList(state) {
    // 1. 依據規則代碼，先將規則答案清單中符合規則代碼的規則答案移除 ---------------------------------------------------------
    remove(
      state.f02010401.ruleAnswerList,
      ruleAnswer => ruleAnswer.ruleId === state.tmpRuleInfo.ruleId
    );

    // 2. 將規則答案清單中的規則參數群組加入規則答案清單 --------------------------------------------------------------------
    state.f02010401.ruleAnswerList = concat(
      state.f02010401.ruleAnswerList,
      filter(
        state.questAnsList,
        questAns => questAns.grpType === "R" // R: 規則參數群組
      )
    );
  },
  /**
   * 清空暫存規則資訊
   * @param {*} state
   */
  doClearTmpRuleInfo(state) {
    state.tmpRuleInfo = {
      activityId: "", // 活動代碼, Ref IRPP.TB_ACTIVITY.ACTIVITY_ID
      ruleId: "", // 規則代碼, Ref IRPP.TB_RULE.RULE_ID
      ruleNm: "", // 規則名稱
      priority: null // 回饋優先序(數值愈大愈優先)
    };
  },
  /**
   * 清空規則參數
   * @param {*} state
   */
  doClearRuleParam(state) {
    state.f02010401 = {
      ruleInfoList: [], // 規則資訊清單
      ruleQuestGroupList: [], // 規則題目群組清單
      ruleQuestList: [], // 規則題目清單
      ruleAnswerList: [] // 規則答案清單
    };
  },
  /**
   * 新增已點擊確認之規則代碼
   * @param {*} state
   * @param {*} payload 規則代碼
   */
  doAddCheckedRuleIds(state, payload) {
    state.checkedRuleIds.add(payload);
  },
  /**
   * 清空已點擊確認之規則代碼清單
   * @param {*} state
   */
  doClearCheckedRuleIds(state) {
    state.checkedRuleIds.clear();
  },

  // 3. 規則參數、活動參數 -----------------------------------------------------------------------------------------------
  /**
   * 新增題目及答案資訊清單
   * @param {*} state
   * @param {*} payload 題目及答案資訊清單
   */
  doAddQuestAnsList(state, payload) {
    state.questAnsList = forEach(
      concat(state.questAnsList, payload),
      (questAns, index) => (questAns.idx = index)
    );
  },
  /**
   * 依題目群組類型清空題目及答案資訊清單
   * @param {*} state
   * @param {*} payload 題目群組類型
   */
  doClearQuestAnsListByType(state, payload) {
    state.questAnsList = forEach(
      filter(
        state.questAnsList,
        questAns => questAns.grpType !== payload.grpType
      ),
      (questAns, index) => (questAns.idx = index)
    );
  },
  /**
   * 更新答案
   * @param {*} state
   * @param {*} payload 答案
   */
  doUpdAnswer(state, payload) {
    find(
      state.questAnsList,
      questAns => payload.grpQuestInfoSeq === questAns.grpQuestInfoSeq
    ).answer = payload.answer;
  }
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
};
