import { DEFAULT_DATE_FORMAT } from "@conf/app-config";
import isBlank from "is-blank";

export default {
  data() {
    return {
      // 預設日期格式
      defaultDateFormat: DEFAULT_DATE_FORMAT,
      // 預設大寫日期格式
      defaultUpperDateFormat: DEFAULT_DATE_FORMAT.toUpperCase()
    };
  },
  methods: {
    /**
     * 更新Form欄位檢核結果
     * @param {*} formName 表單名稱
     * @param {*} field 欄位名稱
     * @param {*} status 狀態(success|error)
     * @param {*} message 訊息
     */
    doUpdVerifyStatus: function(formName, field, status, message) {
      this._.find(this.$refs[formName].fields, {
        prop: field
      }).validateState = status;

      this._.find(this.$refs[formName].fields, {
        prop: field
      }).validateMessage = message;
    },
    /**
     * 更新FormItem欄位檢核結果
     * @param {*} itemName 表單欄位名稱
     * @param {*} status 狀態(success|error)
     * @param {*} message 訊息
     */
    doUpdItemVerifyStatus: function(itemName, status, message) {
      this.$refs[itemName].validateState = status;
      this.$refs[itemName].validateMessage = message;
    },
    /**
     * 限制特定起始日期
     * @param {*} endDate 迄日日期(YYYY/MM/DD)
     * @param {*} disableSDate 限制日期(YYYY/MM/DD)
     */
    restrictSpecificSDate: function(endDate, disableSDate) {
      return {
        disabledDate: date => {
          let startLimit = disableSDate || "1911/01/01";
          let endLimit = endDate || "9999/12/31";

          return (
            date < this.$moment(startLimit, this.defaultUpperDateFormat) ||
            date > this.$moment(endLimit, this.defaultUpperDateFormat)
          );
        }
      };
    },
    /**
     * 限制區間起始日期
     * @param {*} endDate 迄日日期(YYYY/MM/DD)
     * @param {*} timeLabel 時間標籤(years|y、quarters|Q、months|M、weeks|w、days|d)
     * @param {*} duration Type: NUMBER，時間長度
     */
    restrictPeriodSDate: function(endDate, timeLabel, duration) {
      return {
        disabledDate: date => {
          if (isBlank(endDate)) {
            return false;
          }

          let startLimit = this.$moment(
            endDate,
            this.defaultUpperDateFormat
          ).subtract(duration, timeLabel);
          let endLimit = this.$moment(endDate, this.defaultUpperDateFormat);

          return date <= startLimit || date > endLimit;
        }
      };
    },
    /**
     * 限制特定結束日期
     * @param {*} startDate 起日日期(YYYY/MM/DD)
     * @param {*} disableEDate 限制日期(YYYY/MM/DD)
     */
    restrictSpecificEDate: function(startDate, disableEDate) {
      return {
        disabledDate: date => {
          let startLimit = startDate || "1911/01/01";
          let endLimit = disableEDate || "9999/12/31";

          return (
            date > this.$moment(endLimit, this.defaultUpperDateFormat) ||
            date < this.$moment(startLimit, this.defaultUpperDateFormat)
          );
        }
      };
    },
    /**
     *  限制區間結束日期
     * @param {*} startDate 起日日期(YYYY/MM/DD)
     * @param {*} timeLabel 時間標籤(years|y、quarters|Q、months|M、weeks|w、days|d)
     * @param {*} duration Type: NUMBER，時間長度
     */
    restrictPeriodEDate: function(startDate, timeLabel, duration) {
      return {
        disabledDate: date => {
          if (isBlank(startDate)) {
            return false;
          }

          let startLimit = this.$moment(startDate, this.defaultUpperDateFormat);
          let endLimit = this.$moment(
            startDate,
            this.defaultUpperDateFormat
          ).add(duration, timeLabel);

          return date < startLimit || date >= endLimit;
        }
      };
    }
  }
};
