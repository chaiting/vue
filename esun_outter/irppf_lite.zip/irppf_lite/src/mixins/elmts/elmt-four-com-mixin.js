import elmtThreeComMixin from "@mixins/elmts/elmt-three-com-mixin";

export default {
  mixins: [elmtThreeComMixin],
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {
    /**
     * Component 4是否顯示
     */
    isShowCom4: function() {
      return !this.elmtAttrs.com4?.hidden;
    },
    /**
     * Component 4是否停用
     */
    isCom4Disable: function() {
      return this.isComponentDisabled(this.elmtAttrs.com4?.edit);
    },
    /**
     * Component 4選項是否停用查詢模式
     */
    com4SuspendType: function() {
      return this.isCom4Disable ? "" : "N"; // N: 限查詢未停用項目
    },
    /**
     * Component 4檢核規則清單
     */
    com4Rules: function() {
      return this.doQryVerifyRules(this.elmtAttrs.com4?.rules);
    }
  },
  methods: {
    /**
     * 答案4異動處理
     */
    onAns4UpdateHandler: function(ans4) {
      this.doModifyAnswer({ ...this.answer, ans4 });
    },
    /**
     * 日期4答案異動處理
     * @param {*} ans 日期答案
     */
    onAns4DateUpdHandler: function(ans) {
      this.onAns4UpdateHandler(this.doCleanDateFormat(ans));
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
