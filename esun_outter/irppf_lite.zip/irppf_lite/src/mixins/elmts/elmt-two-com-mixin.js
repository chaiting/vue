import isBlank from "is-blank";
import formMgrMixin from "@mixins/form-mgr-mixin";
import elmtBaseMixin from "@mixins/elmts/elmt-base-mixin";

export default {
  mixins: [formMgrMixin, elmtBaseMixin],
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {
    /**
     * Component 1是否顯示
     */
    isShowCom1: function() {
      return !this.elmtAttrs.com1?.hidden;
    },
    /**
     * Component 2是否顯示
     */
    isShowCom2: function() {
      return !this.elmtAttrs.com2?.hidden;
    },
    /**
     * Component 1是否停用
     */
    isCom1Disable: function() {
      return this.isComponentDisabled(this.elmtAttrs.com1?.edit);
    },
    /**
     * Component 2是否停用
     */
    isCom2Disable: function() {
      return this.isComponentDisabled(this.elmtAttrs.com2?.edit);
    },
    /**
     * Component 1選項是否停用查詢模式
     */
    com1SuspendType: function() {
      return this.isCom1Disable ? "" : "N"; // N: 限查詢未停用項目
    },
    /**
     * Component 2選項是否停用查詢模式
     */
    com2SuspendType: function() {
      return this.isCom2Disable ? "" : "N"; // N: 限查詢未停用項目
    },
    /**
     * Component 1檢核規則清單
     */
    com1Rules: function() {
      return this.doQryVerifyRules(this.elmtAttrs.com1?.rules);
    },
    /**
     * Component 2檢核規則清單
     */
    com2Rules: function() {
      return this.doQryVerifyRules(this.elmtAttrs.com2?.rules);
    },
    /**
     * Component 1檢核規則清單(設定規則+com1/com2同時有值或同時沒值)
     */
    com1EitherRules: function() {
      return this._.concat(this.com1Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            // 1. 若2個選項皆無選擇，則清空所有訊息 --------------------------------------------------------------------------------
            if (isBlank(this.answer.ans1) && isBlank(this.answer.ans2)) {
              this.doUpdItemVerifyStatus("com2", "success");
              return callback();
            }

            // 2. 檢核若ans2為空，ans1不為空，Component two顯示提示文字 ------------------------------------------------------------
            if (!isBlank(this.answer.ans1) && isBlank(this.answer.ans2)) {
              this.doUpdItemVerifyStatus("com1", "success", "");
              this.doUpdItemVerifyStatus(
                "com2",
                "error",
                `請選擇有效${this.elmtAttrs.com2.fieldName}`
              );

              return callback();
            }

            // 3. 檢核若ans1為空，ans2不為空，Component one顯示提示文字 ------------------------------------------------------------
            if (isBlank(this.answer.ans1) && !isBlank(this.answer.ans2)) {
              this.doUpdItemVerifyStatus("com2", "success", "");
              return callback(
                new Error(`請選擇有效${this.elmtAttrs.com1.fieldName}`)
              );
            }

            callback();
          }
        }
      ]);
    },
    /**
     * Component 2檢核規則清單(設定規則+com1/com2同時有值或同時沒值)
     */
    com2EitherRules: function() {
      return this._.concat(this.com2Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            // 1. 若2個選項皆無選擇，若com1為非必填則清空所有訊息 -------------------------------------------------------------------
            if (
              isBlank(this.answer.ans1) &&
              isBlank(this.answer.ans2) &&
              !this._.find(this.com1Rules, ["required", true])
            ) {
              this.doUpdItemVerifyStatus("com1", "success");
              return callback();
            }

            // 2. 檢核若ans1為空，ans2不為空，Component one顯示提示文字 ------------------------------------------------------------
            if (isBlank(this.answer.ans1) && !isBlank(this.answer.ans2)) {
              this.doUpdItemVerifyStatus("com2", "success", "");
              this.doUpdItemVerifyStatus(
                "com1",
                "error",
                `請選擇有效${this.elmtAttrs.com1.fieldName}`
              );
              return callback();
            }

            // 3. 檢核若ans2為空，ans1不為空，Component two顯示提示文字 ------------------------------------------------------------
            if (!isBlank(this.answer.ans1) && isBlank(this.answer.ans2)) {
              this.doUpdItemVerifyStatus("com1", "success", "");
              return callback(
                new Error(`請選擇有效${this.elmtAttrs.com2.fieldName}`)
              );
            }

            callback();
          }
        }
      ]);
    }
  },
  methods: {
    /**
     * 答案1異動處理
     */
    onAns1UpdateHandler: function(ans1) {
      this.doModifyAnswer({ ...this.answer, ans1 });
    },
    /**
     * 答案2異動處理
     */
    onAns2UpdateHandler: function(ans2) {
      this.doModifyAnswer({ ...this.answer, ans2 });
    },
    /**
     * 日期1答案異動處理
     * @param {*} ans 日期答案
     */
    onAns1DateUpdHandler: function(ans) {
      this.onAns1UpdateHandler(this.doCleanDateFormat(ans));
    },
    /**
     * 日期2答案異動處理
     * @param {*} ans 日期答案
     */
    onAns2DateUpdHandler: function(ans) {
      this.onAns2UpdateHandler(this.doCleanDateFormat(ans));
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
