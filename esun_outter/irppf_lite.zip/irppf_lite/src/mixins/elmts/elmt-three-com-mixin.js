import elmtTwoComMixin from "@mixins/elmts/elmt-two-com-mixin";

export default {
  mixins: [elmtTwoComMixin],
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {
    /**
     * Component 3是否顯示
     */
    isShowCom3: function() {
      return !this.elmtAttrs.com3?.hidden;
    },
    /**
     * Component 3是否停用
     */
    isCom3Disable: function() {
      return this.isComponentDisabled(this.elmtAttrs.com3?.edit);
    },
    /**
     * Component 3選項是否停用查詢模式
     */
    com3SuspendType: function() {
      return this.isCom3Disable ? "" : "N"; // N: 限查詢未停用項目
    },
    /**
     * Component 3檢核規則清單
     */
    com3Rules: function() {
      return this.doQryVerifyRules(this.elmtAttrs.com3?.rules);
    }
  },
  methods: {
    /**
     * 答案3異動處理
     */
    onAns3UpdateHandler: function(ans3) {
      this.doModifyAnswer({ ...this.answer, ans3 });
    },
    /**
     * 日期3答案異動處理
     * @param {*} ans 日期答案
     */
    onAns3DateUpdHandler: function(ans) {
      this.onAns3UpdateHandler(this.doCleanDateFormat(ans));
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
