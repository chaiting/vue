import { isEmpty } from "@misc/validation-rules";
import elmtTwoMixin from "@mixins/elmts/elmt-two-com-mixin";

export default {
  mixins: [elmtTwoMixin],
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {
    /**
     * 自定義Component1檢核規則清單
     */
    custCom1Rules: function() {
      return this._.concat(this.com1Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            // 1. 若2個選項皆無選擇，則清空Component two訊息 ---------------------------------------------------------------------
            if (
              this.isShowCom1 &&
              isEmpty(this.answer.ans1) &&
              isEmpty(this.answer.ans2)
            ) {
              this.doUpdItemVerifyStatus("com2", "success");
              return callback();
            }

            // 2. 檢核若ans2為空，ans1不為空，Component two顯示提示文字 -----------------------------------------------------------
            if (
              this.isShowCom1 &&
              !isEmpty(this.answer.ans1) &&
              isEmpty(this.answer.ans2)
            ) {
              this.doUpdItemVerifyStatus(
                "com2",
                "error",
                `請選擇${this.elmtAttrs.com2.fieldName}`
              );

              return callback();
            }

            callback();
          }
        }
      ]);
    },
    /**
     * 自定義Component2檢核規則清單
     */
    custCom2Rules: function() {
      return this._.concat(this.com2Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            // 1. 若ans2不為空，則清空訊息 ---------------------------------------------------------------------------------------
            if (this.isShowCom1 && !isEmpty(this.answer.ans2)) {
              this.doUpdItemVerifyStatus("com2", "success");
              return callback();
            }

            // 2. 檢核若ans2為空，ans1不為空，Component two顯示提示文字 -----------------------------------------------------------
            if (
              this.isShowCom1 &&
              !isEmpty(this.answer.ans1) &&
              isEmpty(this.answer.ans2)
            ) {
              return callback(
                new Error(`請選擇${this.elmtAttrs.com2.fieldName}`)
              );
            }

            callback();
          }
        }
      ]);
    }
  },
  methods: {},
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
