import elmtBaseMixin from "@mixins/elmts/elmt-base-mixin";

export default {
  mixins: [elmtBaseMixin],
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {
    /**
     * 元件是否停用
     */
    isDisable: function() {
      return this.isComponentDisabled(this.elmtAttrs.edit);
    },
    /**
     * 元件選項是否停用查詢模式
     */
    suspendType: function() {
      return this.isDisable ? "" : "N"; // N: 限查詢未停用項目
    },
    /**
     * 檢核規則清單
     */
    rules: function() {
      return this.doQryVerifyRules(this.elmtAttrs.rules);
    }
  },
  methods: {
    /**
     * 答案異動處理
     * @param {*} ans 答案
     */
    onUpdateHandler: function(ans) {
      this.doModifyAnswer({
        ans: ans
      });
    },
    /**
     * 日期答案異動處理
     * @param {*} ans 日期答案
     */
    onDateUpdHandler: function(ans) {
      this.onUpdateHandler(this.doCleanDateFormat(ans));
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
