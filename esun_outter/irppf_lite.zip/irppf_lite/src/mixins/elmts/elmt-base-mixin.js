import { mapActions } from "vuex";
import { getRule } from "@misc/validation-rules";
import isBlank from "is-blank";
import dateFormatter from "@/utils/date-formatter";

export default {
  components: {},
  props: {
    // 參數元件模式
    elementMode: {
      type: String,
      required: true,
      validator: function(value) {
        // RW: 可讀寫、PW: 部份可寫、RO: 唯讀
        return ["RW", "PW", "RO"].includes(value);
      }
    },
    // 元件索引
    idx: {
      type: Number,
      required: true
    },
    // 題目
    question: {
      type: Object,
      required: true
    }
  },
  model: {
    event: "update"
  },
  data() {
    return {};
  },
  computed: {
    /**
     * 題目群組對應序號, Ref IRPP.TB_GRP_QUEST_INFO.GRP_QUEST_INFO_SEQ
     */
    grpQuestInfoSeq: function() {
      return this.question?.grpQuestInfoSeq;
    },
    /**
     * 題目名稱
     */
    questNm: function() {
      return this.question?.questNm || "";
    },
    /**
     * 元件屬性值
     */
    elmtAttrs: function() {
      return this.question?.elmtAttrs || {};
    },
    /**
     * 答案
     */
    answer: function() {
      return this.question?.answer || {};
    }
  },
  methods: {
    ...mapActions("f02", ["doUpdAnswer"]),
    /**
     * 清除日期格式符號，移除符號及空白，Ex. 2020/01/01 -> 20200101、2020-01-01 16:12:11 -> 20200101161211
     * @param date 來源日期資料
     * @return 移除符號日期字串
     */
    doCleanDateFormat: function(date) {
      if (isBlank(date)) {
        return date;
      }

      return this._.replace(date, /[^0-9]/g, "");
    },
    /**
     * 格式化日期格式
     * @param date 來源日期資料
     * @return 加入格式化符號日期字串
     */
    doFormatDate: function(date) {
      if (isBlank(date)) {
        return date;
      }

      return dateFormatter.formatDateTime(date, "04"); // 04: YYYY/MM/DD
    },
    /**
     * Component是否停用
     * @param {*} isEditable 是否可編輯
     */
    isComponentDisabled: function(isEditable) {
      // RW: 可讀寫、PW: 部份可寫
      return "RW" === this.elementMode ||
        ("PW" === this.elementMode && isEditable)
        ? false
        : true;
    },
    /**
     * 取得Component檢核規則清單
     * @param {*} ruleNames
     */
    doQryVerifyRules: function(ruleNames) {
      return this._.map(ruleNames, ruleName => {
        return getRule(ruleName);
      });
    },
    /**
     * 異動答案值
     * @param {*} answer 答案
     */
    doModifyAnswer: function(answer) {
      this.$emit("update", answer);

      this.doUpdAnswer({
        grpQuestInfoSeq: this.grpQuestInfoSeq,
        answer: answer
      });
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
