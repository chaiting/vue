import isBlank from "is-blank";
import elmtThreeComMixin from "@mixins/elmts/elmt-three-com-mixin";

export default {
  mixins: [elmtThreeComMixin],
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {
    /**
     * 自定義Component1檢核規則清單
     */
    custCom1Rules: function() {
      return this._.concat(this.com1Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            this.doUpdItemVerifyStatus("com1", "success", "");
            this.doVerifyRule();

            if (this.isShowCom3) {
              this.doCompareCom2Com3();
            }

            let msg = this.$refs["com1"].validateMessage;
            if (!isBlank(msg)) {
              return callback(new Error(msg));
            }

            callback();
          }
        }
      ]);
    },
    /**
     * 起值檢核規則清單
     */
    startValueRules: function() {
      return this._.concat(this.com2Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            this.doUpdItemVerifyStatus("com2", "success", "");
            this.doVerifyRule();

            if (this.isShowCom3) {
              this.doCompareCom2Com3();
            }

            let msg = this.$refs["com2"].validateMessage;
            if (!isBlank(msg)) {
              return callback(new Error(msg));
            }

            callback();
          }
        }
      ]);
    },
    /**
     * 迄值檢核規則清單
     */
    endValueRules: function() {
      return this._.concat(this.com3Rules, [
        {
          trigger: "change",
          validator: (rule, value, callback) => {
            this.doUpdItemVerifyStatus("com3", "success", "");
            this.doVerifyRule();

            if (this.isShowCom3) {
              this.doCompareCom2Com3();
            }

            let msg = this.$refs["com3"].validateMessage;
            if (!isBlank(msg)) {
              return callback(new Error(msg));
            }

            callback();
          }
        }
      ]);
    }
  },
  methods: {
    /**
     * Component 1項目異動處理
     */
    onCom1UpdateHandler: function(event) {
      this.onAns1UpdateHandler(event);
      this.onAns2UpdateHandler("");
      this.onAns3UpdateHandler("");
    },
    /**
     * 客製規則檢核(com1/com2/com3皆沒值或任一沒有值)
     */
    doVerifyRule: function() {
      let ans1 = this.answer.ans1;
      let ans2 = this.answer.ans2;
      let ans3 = this.answer.ans3;

      // 1. 欄位皆沒有值，若為非必填清空錯誤訊息 ---------------------------------------------------------------------
      if (
        isBlank(ans1) &&
        isBlank(ans2) &&
        isBlank(ans3) &&
        !this._.find(this.custCom1Rules, ["required", true])
      ) {
        this.doUpdItemVerifyStatus("com1", "success", "");
        this.doUpdItemVerifyStatus("com2", "success", "");
        this.doUpdItemVerifyStatus("com3", "success", "");
        return;
      }

      // 2. 任一個欄位沒有值，則該Component顯示提示文字 --------------------------------------------------------------
      if (isBlank(ans1)) {
        this.doUpdItemVerifyStatus(
          "com1",
          "error",
          `請選擇${this.elmtAttrs.com1.fieldName}`
        );
      }

      if (isBlank(ans2)) {
        this.doUpdItemVerifyStatus(
          "com2",
          "error",
          `請選擇${this.elmtAttrs.com2.fieldName}`
        );
      }

      if (isBlank(ans3) && this.isShowCom3) {
        this.doUpdItemVerifyStatus(
          "com3",
          "error",
          `請選擇${this.elmtAttrs.com3.fieldName}`
        );
      }
    },
    /**
     * 檢核com2數值需小於com3
     */
    doCompareCom2Com3: function() {
      let ans2 = this.answer.ans2;
      let ans3 = this.answer.ans3;

      let com2ErrMsg = `${this.elmtAttrs.com2.fieldName}不可大於${this.elmtAttrs.com3.fieldName}`;
      let com3ErrMsg = `${this.elmtAttrs.com3.fieldName}不可小於${this.elmtAttrs.com2.fieldName}`;

      // 1. 若ans2及ans3不為空，檢核ans2 < ans3 --------------------------------------------------------------------
      if (!isBlank(ans2) && !isBlank(ans3) && ans2 < ans3) {
        this.doUpdItemVerifyStatus("com2", "sucess", "");
        this.doUpdItemVerifyStatus("com3", "sucess", "");
        return;
      }

      if (!isBlank(ans2) && !isBlank(ans3) && !(ans2 < ans3)) {
        this.doUpdItemVerifyStatus("com2", "error", com2ErrMsg);
        this.doUpdItemVerifyStatus("com3", "error", com3ErrMsg);
        return;
      }

      // 2. ans2為空，清空ans3錯誤訊息 -----------------------------------------------------------------------------
      if (isBlank(ans2) && !isBlank(ans3)) {
        this.doUpdItemVerifyStatus("com3", "sucess", "");
      }

      // 3. ans3為空，清空ans2錯誤訊息 -----------------------------------------------------------------------------
      if (isBlank(ans3) && !isBlank(ans2)) {
        this.doUpdItemVerifyStatus("com2", "sucess", "");
      }
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
