const axios = require("axios");

export default {
  /**
   * 新增敏感性資料並取得資料交換主鍵
   * @param dataContent 資料內容
   */
  doAddSensitiveData: async function(dataContent) {
    let result = await axios.post("/data_exchange/01", {
      dataContent: dataContent
    });

    return result.data.body;
  },
  /**
   * 取得敏感性資料內容
   * @param dataExchangeSeqNo 資料交換主鍵
   */
  doGetSensitiveData: async function(dataExchangeSeqNo) {
    let result = await axios.post("/data_exchange/02", {
      dataExchangeSeqNo: dataExchangeSeqNo
    });

    return result.data.body;
  }
};
