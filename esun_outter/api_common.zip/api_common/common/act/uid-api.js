const axios = require("axios");

export default {
  /**
   * 雪花演算法-取得下一個唯一值ID
   */
  getNextSnowFlakeId: async function() {
    let result = await axios.post("/uid/01");
    return result.data.body;
  }
};
