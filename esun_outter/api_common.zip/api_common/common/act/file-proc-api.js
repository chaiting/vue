const axios = require("axios");
const fileDownload = require("js-file-download");

export default {
  /**
   * 取得檔案範本
   * @param fileType 檔案類型代碼
   */
  doGetFileTemplate: async function(fileType) {
    let result = await axios.post(
      "/file_proc/01",
      {
        fileType: fileType
      },
      {
        responseType: "blob"
      }
    );

    let filename = decodeURI(
      result.headers["content-disposition"].split("filename=")[1]
    ).replaceAll('"', "");

    fileDownload(result.data, filename);
  }
};
