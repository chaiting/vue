const axios = require("axios");

export default {
  /**
   * 依據表單代碼，查詢活動代碼
   * @param payload 查詢條件
   */
  doGetActivityId: async function(payload) {
    let result = await axios.post("/activity/01", payload);
    return result.data.body;
  }
};
