const axios = require("axios");
import isBlank from "is-blank";

export default {
  /**
   * 查詢表單歷程紀錄清單
   * @param payload 查詢條件
   */
  doQryFormHistoryList: async function(payload) {
    let result = await axios.post("/act_component/01", payload);
    return result.data.body;
  },
  /**
   * 查詢回饋品項資訊
   * @param {*} payload 回饋品項資訊查詢參數
   */
  doGetRewardItemInfo: async function(payload) {
    let result = await axios.post("/act_component/02", payload);
    return result.data.body;
  },
  /**
   * 查詢活動代號清單
   * @param {*} payload 活動代號清單查詢參數
   */
  doQryActivityIdList: async function(payload) {
    if (isBlank(payload.activityType)) {
      return [];
    }

    let result = await axios.post("/act_component/03", payload);
    return result.data.body;
  },
  /**
   * 查詢近一年半內活動贈品碼清單
   */
  doQryActGiftIdList: async function() {
    let result = await axios.post("/act_component/04");
    return result.data.body;
  },
  /**
   * 查詢MCC清單
   */
  doQryMCCList: async function() {
    let result = await axios.post("/act_component/05");
    return result.data.body;
  },
  /**
   * 查詢收單BIN代碼清單
   * @param {*} payload 收單BIN代碼清單查詢參數
   */
  doQryAcqBinList: async function(payload) {
    let result = await axios.post("/act_component/06", payload);
    return result.data.body;
  },
  /**
   * 查詢顧客資訊
   * @param {*} payload 查詢條件
   */
  doGetCustomerInfo: async function(payload) {
    let result = await axios.post("/act_component/07", payload);
    return result.data.body;
  },
  /**
   * 查詢活動類型代碼
   */
  doGetActivityType: async function(payload) {
    let result = await axios.post("/act_component/08", payload);
    return result.data.body;
  }
};
