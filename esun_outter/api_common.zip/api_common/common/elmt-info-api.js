const axios = require("axios");
import isBlank from "is-blank";

export default {
  /**
   * 查詢近一年的活動名單清單
   * @param {*} payload 活動名單清單查詢參數
   */
  doQryRosterList: async function(payload) {
    let result = await axios.post("/elmt_info/01", payload);
    return result.data.body;
  },
  /**
   * 查詢已結案活動群組清單
   * @param {*} payload 活動群組查詢參數
   */
  doQryActGrpList: async function(payload) {
    let result = await axios.post("/elmt_info/02", payload);
    return result.data.body;
  },
  /**
   * 查詢回饋品項清單
   * @param {*} payload 回饋品項查詢參數
   */
  doQryRewardItemList: async function(payload) {
    if (isBlank(payload.upItemId)) {
      return [];
    }

    let result = await axios.post("/elmt_info/03", payload);
    return result.data.body;
  },
  /**
   * 查詢流通卡片清單
   * @param {*} payload 卡片查詢參數
   */
  doQryCardList: async function(payload) {
    if (isBlank(payload.chid) || isBlank(payload.cardType)) {
      return [];
    }

    let result = await axios.post("/elmt_info/04", payload);
    return result.data.body;
  }
};
