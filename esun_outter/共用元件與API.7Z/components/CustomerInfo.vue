<template>
  <div class="float-menu" :class="{ open: isVisible }">
    <div class="menu-banner" @click="toggleOpen">
      <Icon type="md-person" />綜合資訊
    </div>
    <div class="menu-content" :class="{ open: isVisible }">
      <div class="menu-title" @click="toggleOpen">
        <Icon class="mr-10" type="ios-menu" />
        <span>顧客綜合資訊</span>
      </div>
      <ul>
        <li @click="openModal('COMMON')">常用資訊</li>
        <li @click="isCorp ? openModal('JCIC_CORP') : openModal('JCIC_CH')">
          聯徵資訊
        </li>
        <li @click="openEpspPage">顧客資訊</li>
        <li @click="openModal('ADJ_RECORD')">調額資訊</li>
      </ul>
    </div>

    <Modal v-model="isModalVisible" width="1400" footer-hide>
      <Tabs
        type="card"
        class="tabs-extra"
        v-model="currentTab"
        @on-click="name => toView(name)"
      >
        <TabPane
          v-for="tab in currentTabs"
          :key="tabsType + tab.view"
          :name="tab.view"
          :label="tab.label"
        ></TabPane>
      </Tabs>

      <div style="margin-top: 20px">
        <keep-alive exclude="^F04.*$">
          <!-- 聯徵相關(F04)每次重建 components  -->
          <component
            :is="view"
            :caseType="caseType"
            :customerId="customerId"
            :customerNm="customerNm"
            :caseNo="caseNo"
            :lastQryDate="lastQryDate"
            :chid="customerId"
            :bizid="customerId"
            :format="format /** for ...債務, 不同債務 format 不同 */"
            :queryCount="0 /** for 整合資訊, 要重查則+1 */"
            :isShowLoan="true /** for 各產品線風險狀態, 要查到卡友貸*/"
            :snapshotView="snapshotView"
          />
        </keep-alive>
      </div>
    </Modal>
  </div>
</template>

<script>
import f080101Api from "@/api/f08/f080101-api";

import F080101SCN from "@components/f08/F080101SCN.vue";
import F080102SCN from "@components/f08/F080102SCN.vue";
import F080103SCN from "@components/f08/F080103SCN.vue";
import F080104SCN from "@components/f08/F080104SCN.vue";
import F080201SCN from "@components/f08/F080201SCN.vue";
import F080202SCN from "@components/f08/F080202SCN.vue";
import F080203SCN from "@components/f08/F080203SCN.vue";
import F080204SCN from "@components/f08/F080204SCN.vue";
import F080205SCN from "@components/f08/F080205SCN.vue";
import F030702SCN from "@components/f03/F030702SCN.vue";
import F030902SCN from "@components/f03/F030902SCN.vue";
import F031102SCN from "@components/f03/F031102SCN.vue";
import F031202SCN from "@components/f03/F031202SCN.vue";
import F040302SCN from "@components/f04/F040302SCN.vue";
import F040303SCN from "@components/f04/F040303SCN.vue";
import F040307SCN from "@components/f04/F040307SCN.vue";
import F040308SCN from "@components/f04/F040308SCN.vue";
import F040309SCN from "@components/f04/F040309SCN.vue";
import F040310SCN from "@components/f04/F040310SCN.vue";
import F040311SCN from "@components/f04/F040311SCN.vue";
import F040312SCN from "@components/f04/F040312SCN.vue";
import F040313SCN from "@components/f04/F040313SCN.vue";
import F040314SCN from "@components/f04/F040314SCN.vue";
import F040315SCN from "@components/f04/F040315SCN.vue";
import F040316SCN from "@components/f04/F040316SCN.vue";
import F040317SCN from "@components/f04/F040317SCN.vue";
import F040318SCN from "@components/f04/F040318SCN.vue";
import F040319SCN from "@components/f04/F040319SCN.vue";

const tabs = {
  ADJ: {
    // 常用資訊
    COMMON: [
      { view: "F080101SCN", label: "收入、負債及特殊註記" },
      { view: "F080102SCN", label: "調額 DBR 計算公式查詢" },
      { view: "F080201SCN", label: "金融帳戶帳務資料" },
      { view: "F080202SCN", label: "薪轉資料明細" },
      { view: "F080203SCN", label: "批覆書查詢" },
      { view: "F080204SCN", label: "擔保品查詢" },
      { view: "F080205SCN", label: "事故查詢" }
    ],
    // 聯徵資訊(自然人)
    JCIC_CH: [
      { view: "F040302SCN", label: "整合資訊" }, // prop queryCount
      { view: "F040307SCN", label: "帳款資料", hideInSView: true },
      { view: "F040308SCN", label: "每週帳款餘額", hideInSView: true },
      { view: "F040309SCN", label: "基本資料", hideInSView: true },
      { view: "F040310SCN", label: "持卡明細", hideInSView: true },
      { view: "F040311SCN", label: "被查詢紀錄", hideInSView: true },
      { view: "F040312SCN", label: "授信還款", hideInSView: true },
      { view: "F040313SCN", label: "授信餘額變動", hideInSView: true },
      { view: "F040314SCN", label: "新增授信清償", hideInSView: true },
      { view: "F040315SCN", label: "副擔保授信", hideInSView: true },
      { view: "F040316SCN-BAM305", label: "共同債務", hideInSView: true }, // prop format
      { view: "F040316SCN-BAM306", label: "從債務", hideInSView: true }, // prop format
      { view: "F040317SCN", label: "任董監事資料", hideInSView: true },
      { view: "F040318SCN", label: "學生報送紀錄", hideInSView: true },
      { view: "F040319SCN", label: "爭議案件", hideInSView: true }
    ],
    // 聯徵資訊(法人)
    JCIC_CORP: [
      { view: "F040303SCN", label: "整合資訊" }, // prop queryCount
      { view: "F040307SCN", label: "帳款資料", hideInSView: true },
      { view: "F040310SCN", label: "持卡明細", hideInSView: true },
      { view: "F040311SCN", label: "被查詢紀錄", hideInSView: true },
      { view: "F040312SCN", label: "授信還款", hideInSView: true },
      { view: "F040313SCN", label: "授信餘額變動", hideInSView: true },
      { view: "F040316SCN-BAM305", label: "共同債務", hideInSView: true },
      { view: "F040316SCN-BAM306", label: "從債務", hideInSView: true },
      { view: "F040316SCN-BAM307", label: "其他債務授信", hideInSView: true },
      { view: "F040319SCN", label: "爭議案件", hideInSView: true }
    ],
    // 調額紀錄
    ADJ_RECORD: [{ view: "F080104SCN", label: "調額紀錄" }]
  },
  MID: {
    // 常用資訊
    COMMON: [
      { view: "F080103SCN", label: "無擔紀錄" },
      { view: "F080201SCN", label: "金融帳戶帳務資料" },
      { view: "F080202SCN", label: "薪轉資料明細" },
      { view: "F031102SCN", label: "同業通報強停紀錄" },
      { view: "F031202SCN", label: "支拒紀錄" },
      { view: "F030902SCN", label: "分行退票紀錄" },
      { view: "F030702SCN", label: "各產品線風險狀態" }
    ],
    // 聯徵資訊(自然人)
    JCIC_CH: [
      { view: "F040302SCN", label: "整合資訊" }, // prop queryCount
      { view: "F040307SCN", label: "帳款資料", hideInSView: true },
      { view: "F040308SCN", label: "每週帳款餘額", hideInSView: true },
      { view: "F040309SCN", label: "基本資料", hideInSView: true },
      { view: "F040310SCN", label: "持卡明細", hideInSView: true },
      { view: "F040311SCN", label: "被查詢紀錄", hideInSView: true },
      { view: "F040312SCN", label: "授信還款", hideInSView: true },
      { view: "F040313SCN", label: "授信餘額變動", hideInSView: true },
      { view: "F040314SCN", label: "新增授信清償", hideInSView: true },
      { view: "F040315SCN", label: "副擔保授信", hideInSView: true },
      { view: "F040316SCN-BAM305", label: "共同債務", hideInSView: true }, // prop format
      { view: "F040316SCN-BAM306", label: "從債務", hideInSView: true }, // prop format
      { view: "F040317SCN", label: "任董監事資料", hideInSView: true },
      { view: "F040318SCN", label: "學生報送紀錄", hideInSView: true },
      { view: "F040319SCN", label: "爭議案件", hideInSView: true }
    ],
    // 聯徵資訊(法人)
    JCIC_CORP: [
      { view: "F040303SCN", label: "整合資訊" }, // prop queryCount
      { view: "F040307SCN", label: "帳款資料", hideInSView: true },
      { view: "F040310SCN", label: "持卡明細", hideInSView: true },
      { view: "F040311SCN", label: "被查詢紀錄", hideInSView: true },
      { view: "F040312SCN", label: "授信還款", hideInSView: true },
      { view: "F040313SCN", label: "授信餘額變動", hideInSView: true },
      { view: "F040316SCN-BAM305", label: "共同債務", hideInSView: true },
      { view: "F040316SCN-BAM306", label: "從債務", hideInSView: true },
      { view: "F040316SCN-BAM307", label: "其他債務授信", hideInSView: true },
      { view: "F040319SCN", label: "爭議案件", hideInSView: true }
    ],
    // 調額紀錄
    ADJ_RECORD: [{ view: "F080104SCN", label: "調額紀錄" }]
  }
};

export default {
  components: {
    F080101SCN,
    F080102SCN,
    F080103SCN,
    F080104SCN,
    F080201SCN,
    F080202SCN,
    F080203SCN,
    F080204SCN,
    F080205SCN,
    F030702SCN,
    F030902SCN,
    F031102SCN,
    F031202SCN,
    F040302SCN,
    F040303SCN,
    F040307SCN,
    F040308SCN,
    F040309SCN,
    F040310SCN,
    F040311SCN,
    F040312SCN,
    F040313SCN,
    F040314SCN,
    F040315SCN,
    F040316SCN,
    F040317SCN,
    F040318SCN,
    F040319SCN
  },
  props: {
    // Tabs 類型
    tabsType: {
      type: String,
      required: true,
      validator: val => {
        return ["ADJ", "MID"].includes(val); // ADJ: 調額, MID: 期中
      }
    },
    // 顧客 ID
    customerId: {
      type: String,
      required: true
    },
    // 顧客姓名
    customerNm: {
      type: String,
      required: true
    },
    // 案件編號
    caseNo: {
      type: String,
      required: true
    },
    // 最後查詢日期
    lastQryDate: {
      type: String,
      required: false
    },
    // 是否顯示為快照模式
    snapshotView: {
      type: Boolean,
      required: false
    }
  },
  data() {
    return {
      view: "", // 顯示元件
      format: "", // 顯示格式
      currentTabs: [], // 當前標籤列
      currentTab: "", // 當前標籤
      isVisible: false, // 顧客綜合資訊 Float Menu 顯示與否
      isModalVisible: false // 顧客綜合資訊 Modal 顯示與否
    };
  },
  computed: {
    /**
     * 是否為法人
     */
    isCorp: function() {
      return this.customerId.length === 8; // 8碼統編
    },
    /**
     * 案件類型
     */
    caseType: function() {
      if (this.tabsType == "ADJ") {
        //ADJ: 調額
        return "02"; // 02: 調額案件
      }
      return "01"; //01: 期中案件
    }
  },
  methods: {
    /**
     * 開關側列
     */
    toggleOpen: function() {
      this.isVisible = !this.isVisible;
    },
    /**
     * 切換頁面
     */
    toView: function(view) {
      if (this._.startsWith(view, "F040316SCN")) {
        // 債務系列要多 prop "format" 呈現不同頁面
        [this.view, this.format] = view.split("-");
      } else {
        this.view = view;
      }
    },
    /**
     * 開啟常用資訊
     */
    openModal: function(infoType) {
      this.currentTabs = tabs[this.tabsType][infoType];
      if (this.snapshotView) {
        this.currentTabs = this.currentTabs.filter(v => !v.hideInSView);
      }
      this.currentTab = this.currentTabs[0].view;
      this.toView(this.currentTab); // 預設開啟第一個分頁
      this.isModalVisible = true;
    },
    /**
     * 開啟 EPSP 顧客基本資料頁面
     */
    openEpspPage: async function() {
      let result = await f080101Api.doAddSensitiveData({
        customerId: this.customerId
      });

      window.open(
        process.env.VUE_APP_EPSP_HOME_URL + "/f080901scn?infoKey=" + result
      );
    }
  },
  watch: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {
    // 離開畫面時須關閉所有彈出窗
    this.isVisible = false;
    this.isModalVisible = false;
    this.view = "";
  },
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped>
.float-menu {
  position: fixed;
  cursor: pointer;
  right: 0;
  top: 40%;
  z-index: 99;
  background-color: lightgray;
  font-size: 18px;
}
.menu-banner {
  position: fixed;
  right: 0px;
  background-color: #45b29d;
  box-shadow: -3px 3px 6px gray;
  writing-mode: vertical-rl;
  width: 50px;
  text-align: center;
  line-height: 50px;
  padding: 20px 0px;
  letter-spacing: 5px;
  color: white;
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
  display: flex;
  align-items: center;
  transition: all 0.2s;
}
.menu-content {
  position: fixed;
  right: 0px;
  background-color: #45b29d;
  padding: 10px;
  transform: translate(100%);
  transition: all 0.2s;
  color: white;
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
}
.float-menu.open .menu-banner {
  transform: translate(100%);
  box-shadow: 0px;
}
.float-menu.open .menu-content {
  transform: translate(0%);
  box-shadow: -3px 3px 6px gray;
}
ul {
  padding-top: 10px;
  padding-left: 20px;
}
.menu-title {
  background-color: #3a907f;
  margin: -10px -10px 0px -10px;
  border-top-left-radius: 10px;
  padding: 10px;
}
.tabs-extra {
  margin-top: 20px;
}
::v-deep .ivu-tabs.ivu-tabs-card > .ivu-tabs-bar .ivu-tabs-tab {
  line-height: 20px;
  white-space: pre-line;
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
