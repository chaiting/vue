<template>
  <Select
    v-model="selectedUsers"
    clearable
    filterable
    :disabled="readonly"
    :multiple="multiple"
    :placeholder="placeholder"
    @on-change="$emit('update:value', $event)"
    @on-clear="$emit('update:value', $event)"
  >
    <Option
      v-for="user in userList"
      :value="user.usedAccount"
      :key="user.usedAccount"
      :class="user.hireSts"
      >{{ user.empNm }}</Option
    >
  </Select>
</template>

<script>
import isBlank from "is-blank";
import employeeApi from "@api/common/employee-api";

export default {
  components: {},
  props: {
    // 下拉選單選中的值
    value: {
      type: [String, Array],
      required: false
    },
    // 組織/群組代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    grpIdList: {
      type: Array,
      required: false
    },
    // Value類型, A: AD帳號、E: 員工編號
    valueType: {
      type: String,
      required: false,
      default: "A",
      validator: function(value) {
        return ["A", "E"].includes(value);
      }
    },
    // 是否限在職人員(Y|N)
    isHiredOnly: {
      type: String,
      required: false,
      default: "Y",
      validator: function(value) {
        return ["", "Y", "N"].includes(value);
      }
    },
    // 是否包含單位層級(含子單位)以下所有人(Y|N)
    allSubordinate: {
      type: String,
      required: false,
      default: "N",
      validator: function(value) {
        return ["", "Y", "N"].includes(value);
      }
    },
    // 是否可多選
    multiple: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否唯讀
    readonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 選擇框默認文字
    placeholder: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      // 使用者清單
      userList: [],
      // 選中的AD帳號清單
      selectedUsers: []
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢使用者清單
     */
    doQryUserList: async function() {
      this.userList = [];

      let grpId =
        this._.filter(this.grpIdList, row => {
          return !isBlank(row);
        }) || [];

      if (grpId.length < 1) {
        return;
      }

      this.userList = await employeeApi.doQryUserList({
        grpIdList: grpId,
        isHiredOnly: this.isHiredOnly,
        allSubordinate: this.allSubordinate,
        valueType: this.valueType
      });
    },
    /**
     * 若選單中存在父元件選值則改選中值, 不存在則清空父元件選值
     */
    doUpdateSelectedValue: async function() {
      await this.doQryUserList();

      let vm = this;
      vm.selectedUsers = vm.value;
      if (!vm.selectedUsers || vm.selectedUsers.length < 1) {
        return;
      }

      let isExists = vm._.find(vm.userList, function(o) {
        return vm._.includes(vm.selectedUsers, o.usedAccount);
      });

      if (!isExists) {
        this.$emit("update:value", null);
      }
    }
  },
  watch: {
    /**
     * 監聽組織/群組代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
     */
    grpIdList: {
      handler: function() {
        this.doUpdateSelectedValue();
      },
      deep: true
    },
    /**
     * 監聽是否限在職人員(Y|N)
     */
    isHiredOnly: function() {
      this.doUpdateSelectedValue();
    }
  },
  beforeCreate() {},
  created() {
    this.doUpdateSelectedValue();
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped>
.left {
  color: #b3b3b3;
}
</style>
