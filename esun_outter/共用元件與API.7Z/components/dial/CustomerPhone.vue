<template>
  <div>
    <Row type="flex" justify="center" align="middle">
      <Col :span="dialBtnSpan">
        <Button
          v-if="dialable"
          icon="ios-call"
          type="primary"
          @click="dialComfirm = true"
        ></Button>
      </Col>
      <Col :span="msgSpan"> {{ dialInfo }}：{{ phoneInfo }} </Col>
    </Row>

    <!-- 撥號確認視窗 -->
    <Modal
      v-model="dialComfirm"
      title="系統撥號"
      class="esun-modal"
      width="50vh"
    >
      <Row>
        <Col span="15">
          顧客名稱：
          <Tooltip
            max-width="200"
            :content="customerName"
            placement="top"
            transfer
          >
            <span>{{ customerInfo }}</span>
          </Tooltip>
        </Col>
        <Col span="9">顧客ID：{{ customerId }} </Col>
      </Row>
      <Row>
        <Col span="15">
          <div>撥號號碼： {{ dialInfo + calledNumber }}</div>
        </Col>
        <Col span="9" v-if="businessId">業務編號：{{ businessId }} </Col>
      </Row>
      <Form
        ref="callingReason"
        class="esun-form margin-form"
        :label-width="120"
        :model="callingReason"
        :rules="validateRule"
      >
        <FormItem label="通話原因類型" prop="reasonCd">
          <sys-cd-select
            :ctId="318"
            :value.sync="callingReason.reasonCd"
            flag01="Y"
            placeholder="請選擇類型"
            suspend="N"
          ></sys-cd-select>
        </FormItem>
        <FormItem label="通話原因備註" prop="reasonDesc">
          <Input
            v-model="callingReason.reasonDesc"
            type="textarea"
            placeholder="內文補充說明..."
            maxlength="100"
            :autosize="{ minRows: 2, maxRows: 5 }"
            :show-word-limit="true"
          ></Input>
        </FormItem>
      </Form>
      <div slot="footer">
        <Button type="info" class="cus-btn-mid" @click="dialComfirm = false">
          取消
        </Button>
        <Button type="primary" class="cus-btn-mid" @click="doAutoCall">
          確定
        </Button>
      </div>
    </Modal>

    <!-- 撥號提示 -->
    <esun-alert
      :value.sync="dialAlert"
      :title="dialAlertTitle"
      :content="dialAlertContent"
    ></esun-alert>

    <!-- 系統撥號顯示 -->
    <esun-alert :value.sync="dialingAlert" title="通知">
      <div>系統撥號中...</div>
      <div style="font-weight: bold; margin-top: 5px">請拿起話筒進行通話</div>
    </esun-alert>
  </div>
</template>

<script>
import isBlank from "is-blank";
import codeApi from "@api/core/code-api";
import sysDialApi from "@api/common/sys-dial-api";

export default {
  components: {},
  props: {
    // 發話號碼
    callingNumber: {
      type: String,
      required: true
    },
    // 是否允許撥號
    isDialable: {
      type: Boolean,
      required: true,
      default: false
    },
    // 顧客ID
    customerId: {
      type: String,
      required: true
    },
    // 受話電話來源, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=16
    telType: {
      type: String,
      required: true
    },
    // 受話號碼
    calledNumber: {
      type: String,
      required: false
    },
    // 顧客姓名
    customerName: {
      type: String,
      required: false
    },
    // 顧客性別, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=159
    customerSex: {
      type: String,
      required: false
    },
    // 功能代碼
    srcFuncCode: {
      type: String,
      required: true
    },
    // 功能代碼名稱
    srcFuncName: {
      type: String,
      required: true
    },
    // 業務編號
    businessId: {
      type: String,
      required: false
    },
    // 通話原因類型, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=318
    reasonCd: {
      type: String,
      required: false,
      default: "01" // 01: 業務執行
    },
    // 按鈕的佔位格數，可選總計0〜24的整數，為0時，相當於display:none
    dialBtnSpan: {
      type: Number,
      required: false,
      default: 3
    },
    // 文字訊息的佔位格數，可選總計0〜24的整數，為0時，相當於display:none
    msgSpan: {
      type: Number,
      required: false,
      default: 21
    }
  },
  data() {
    return {
      // 撥號提示顯示
      dialAlert: false,
      // 撥號提示標題
      dialAlertTitle: "",
      // 撥號提示內容
      dialAlertContent: "",
      // 系統撥號顯示
      dialingAlert: false,
      // 系統撥號確認
      dialComfirm: false,
      // 顧客性別名稱
      sexName: "",
      // 受話電話來源名稱
      phoneTypeName: "",
      // 通話原因表單
      callingReason: {
        reasonCd: "",
        reasonDesc: ""
      },
      // 通話原因表單驗證
      validateRule: {
        reasonCd: [
          {
            required: true,
            message: "通話原因類型為必填欄位",
            trigger: "change"
          }
        ]
      }
    };
  },
  computed: {
    /**
     * 受話號碼資訊
     */
    dialInfo: function() {
      return this.phoneTypeName + "(" + this.telType + ") ";
    },
    /**
     * 受話電話號碼
     */
    phoneInfo: function() {
      return isBlank(this.calledNumber) ? "－" : this.calledNumber;
    },
    /**
     * 顧客短名稱
     */
    shortNm: function() {
      return this._.truncate(this.customerName, { length: 20, separator: " " });
    },
    /**
     * 顧客性別名稱
     */
    sexInfo: function() {
      return isBlank(this.sexName) ? "" : "(" + this.sexName + ")";
    },
    /**
     * 顧客資訊
     */
    customerInfo: function() {
      return this.shortNm + this.sexInfo;
    },
    /**
     * 允許撥號
     */
    dialable: function() {
      return this.isDialable && !isBlank(this.calledNumber);
    }
  },
  methods: {
    /**
     * 系統撥號
     */
    doAutoCall: async function() {
      if (isBlank(this.callingNumber) || this.callingNumber === "****") {
        this.dialAlertTitle = "尚未登錄分機";
        this.dialAlertContent = "請至EPSP支付服務整合系統首頁進行指定分機編輯";
        this.dialAlert = true;
        return;
      }

      this.$refs["callingReason"].validate(async valid => {
        if (valid) {
          await sysDialApi.doSystemCall({
            callingNumber: this.callingNumber,
            calledNumber: this.calledNumber,
            calledId: this.customerId,
            calledInfo: this.customerName,
            calledNumberSrcField: this.telType,
            calledObjType: "A", // A: 顧客
            srcFuncCode: this.srcFuncCode,
            srcFuncName: this.srcFuncName,
            refProcKey: this.businessId,
            reasonCd: this.callingReason.reasonCd,
            reasonDesc: this.callingReason.reasonDesc
          });

          this.dialComfirm = false;
          this.dialingAlert = true;
          setTimeout(() => {
            this.dialingAlert = false;
          }, 3000);
        }
      });
    }
  },
  watch: {
    /**
     * 監聽顧客性別
     */
    customerSex: {
      handler: async function() {
        if (!isBlank(this.customerSex)) {
          this.sexName = await codeApi.doGetCodeName(159, this.customerSex);
        }
      },
      immediate: true
    },
    /**
     * 監聽受話電話來源
     */
    telType: {
      handler: async function() {
        if (!isBlank(this.telType)) {
          this.phoneTypeName = await codeApi.doGetCodeName(16, this.telType);
        }
      },
      immediate: true
    }
  },
  beforeCreate() {},
  created() {
    this.callingReason.reasonCd = this.reasonCd;
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped>
.margin-form {
  margin-top: 15px;
}
</style>
