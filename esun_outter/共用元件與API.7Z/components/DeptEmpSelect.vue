<template>
  <div>
    <Row>
      <!-- L50: 總處單位 -->
      <Col :span="colSpan" v-if="isShowAdminDivision">
        <FormItem prop="selectedAdminDivision" :label="adminDivisionLabel">
          <department-select
            :value.sync="selectedAdminDivision"
            :upGrpIdList="upAdminDivisions"
            :activatedGrp="activatedGrp"
            :readonly="adminDivisionReadonly"
            grpUnitcode="L50"
            placeholder="請選擇總處"
            @update:value="onAdminDivisionChangeHandler"
          ></department-select>
        </FormItem>
      </Col>

      <!-- L55: 處級單位 -->
      <Col :span="colSpan" v-if="isShowDivision">
        <FormItem prop="selectedDivision" :label="divisionLabel">
          <department-select
            :value.sync="selectedDivision"
            :upGrpIdList="upDivisions"
            :activatedGrp="activatedGrp"
            :readonly="divisionReadonly"
            grpUnitcode="L55"
            placeholder="請選擇事業處"
            @update:value="onDivisionChangeHandler"
          ></department-select>
        </FormItem>
      </Col>

      <!-- L60: 部級單位 -->
      <Col :span="colSpan" v-if="isShowDepartment">
        <FormItem prop="selectedDepartment" :label="departmentLabel">
          <department-select
            :value.sync="selectedDepartment"
            :upGrpIdList="upDepartments"
            :activatedGrp="activatedGrp"
            :readonly="departmentReadonly"
            grpUnitcode="L60"
            placeholder="請選擇部門"
            @update:value="onDepartmentChangeHandler"
          ></department-select>
        </FormItem>
      </Col>

      <!-- L70: 區級單位 -->
      <Col :span="colSpan" v-if="isShowDistrict">
        <FormItem prop="selectedDistrict" :label="districtLabel">
          <department-select
            :value.sync="selectedDistrict"
            :upGrpIdList="upDistricts"
            :activatedGrp="activatedGrp"
            :readonly="districtReadonly"
            grpUnitcode="L70"
            placeholder="請選擇分區"
            @update:value="onDistrictChangeHandler"
          ></department-select>
        </FormItem>
      </Col>

      <!-- L80: 中心/分行單位 -->
      <Col :span="colSpan" v-if="isShowCenter">
        <FormItem prop="selectedCenter" :label="centerLabel">
          <department-select
            :value.sync="selectedCenter"
            :upGrpIdList="upCenters"
            :activatedGrp="activatedGrp"
            :readonly="centerReadonly"
            grpUnitcode="L80"
            placeholder="請選擇中心/分行"
            @update:value="onCenterChangeHandler"
          ></department-select>
        </FormItem>
      </Col>

      <!-- L90: 科組單位 -->
      <Col :span="colSpan" v-if="isShowSection">
        <FormItem prop="selectedSection" :label="sectionLabel">
          <department-select
            :value.sync="selectedSection"
            :upGrpIdList="upSections"
            :activatedGrp="activatedGrp"
            :readonly="sectionReadonly"
            grpUnitcode="L90"
            placeholder="請選擇科組"
            @update:value="onSectionChangeHandler"
          ></department-select>
        </FormItem>
      </Col>

      <!-- 人員 -->
      <Col :span="colSpan" v-if="isShowUser">
        <FormItem prop="selectedUser" :label="userLabel">
          <employee-select
            :value.sync="selectedUser"
            :grpIdList="grpIdList"
            :valueType="userValueType"
            :isHiredOnly="isHiredOnly"
            :allSubordinate="allSubordinate"
            :readonly="userReadonly"
            placeholder="請選擇人員"
          ></employee-select>
        </FormItem>
      </Col>
    </Row>
  </div>
</template>

<script>
import departmentApi from "@api/common/department-api";

export default {
  components: {},
  props: {
    // 根節點組織/群組代碼清單, Ref DATAASYNC.TB_GROUP.GRP_ID
    rootGrpId: {
      type: String,
      required: false,
      default: "C004AA" // C004AA: 總經理室
    },
    // 總處級單位代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    adminDivisionId: {
      type: String,
      required: false,
      default: "C810AA" // C810AA: 信用卡總處
    },
    // 處級單位代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    divisionId: {
      type: String,
      required: false
    },
    // 部級單位代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    departmentId: {
      type: String,
      required: false
    },
    // 區級單位代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    districtId: {
      type: String,
      required: false
    },
    // 中心/分行單位代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    centerId: {
      type: String,
      required: false
    },
    // 科組單位代碼, Ref DATAASYNC.TB_GROUP.GRP_ID
    sectionId: {
      type: String,
      required: false
    },
    // 使用者代碼
    userId: {
      type: String,
      required: false
    },
    // 總處級單位是否顯示
    isShowAdminDivision: {
      type: Boolean,
      required: false,
      default: true
    },
    // 處級單位是否顯示
    isShowDivision: {
      type: Boolean,
      required: false,
      default: true
    },
    // 部級單位是否顯示
    isShowDepartment: {
      type: Boolean,
      required: false,
      default: true
    },
    // 區級單位是否顯示
    isShowDistrict: {
      type: Boolean,
      required: false,
      default: true
    },
    // 中心/分行單位是否顯示
    isShowCenter: {
      type: Boolean,
      required: false,
      default: true
    },
    // 科組單位是否顯示
    isShowSection: {
      type: Boolean,
      required: false,
      default: true
    },
    // 使用者是否顯示
    isShowUser: {
      type: Boolean,
      required: false,
      default: true
    },
    // Label是否顯示
    isShowLabel: {
      type: Boolean,
      required: false,
      default: true
    },
    // 總處級單位是否唯讀
    adminDivisionReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 處級單位是否唯讀
    divisionReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 部級單位是否唯讀
    departmentReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 區級單位是否唯讀
    districtReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 中心/分行單位是否唯讀
    centerReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 科組單位是否唯讀
    sectionReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 人員是否唯讀
    userReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否限啟用組織/群組(Y|N)
    activatedGrp: {
      type: String,
      required: false,
      default: "Y" // Y: 限啟用組織/群組
    },
    // 是否限在職人員(Y|N)
    isHiredOnly: {
      type: String,
      required: false,
      default: "Y" // Y: 限在職人員
    },
    // 是否包含所有子單位(Y|N)
    allSubordinate: {
      type: String,
      required: false,
      default: "N" // N: 不包含子單位
    },
    // User Value類型, A: AD帳號、E: 員工編號
    userValueType: {
      type: String,
      required: false,
      default: "A" // A: AD帳號
    },
    // 上方的佔位格數，可選總計0〜24的整數，為0時，相當於display:none
    colSpan: {
      type: Number,
      required: false,
      default: 8
    }
  },
  data() {
    return {
      // 所選根節點單位
      selectedRootGrpId: "",
      // 所選總處級單位
      selectedAdminDivision: "",
      // 所選處級單位
      selectedDivision: "",
      // 所選部級單位
      selectedDepartment: "",
      // 所選區級單位
      selectedDistrict: "",
      // 所選中心/分行單位
      selectedCenter: "",
      // 所選科組單位
      selectedSection: "",
      // 所選使用者
      selectedUser: ""
    };
  },
  computed: {
    /**
     * 總處級單位的上層單位
     */
    upAdminDivisions: function() {
      return [this.selectedRootGrpId];
    },
    /**
     * 處級單位的上層單位
     */
    upDivisions: function() {
      return [this.selectedAdminDivision || this.selectedRootGrpId];
    },
    /**
     * 部級單位的上層單位
     */
    upDepartments: function() {
      return [
        this.selectedDivision ||
          this.selectedAdminDivision ||
          this.selectedRootGrpId
      ];
    },
    /**
     * 區級單位的上層單位
     */
    upDistricts: function() {
      return [
        this.selectedDepartment ||
          this.selectedDivision ||
          this.selectedAdminDivision ||
          this.selectedRootGrpId
      ];
    },
    /**
     * 中心/分行單位的上層單位
     */
    upCenters: function() {
      return [
        this.selectedDistrict ||
          this.selectedDepartment ||
          this.selectedDivision ||
          this.selectedAdminDivision ||
          this.selectedRootGrpId
      ];
    },
    /**
     * 科組單位的上層單位
     */
    upSections: function() {
      return [
        this.selectedCenter ||
          this.selectedDistrict ||
          this.selectedDepartment ||
          this.selectedDivision ||
          this.selectedAdminDivision ||
          this.selectedRootGrpId
      ];
    },
    /**
     * 使用者組織/群組代碼清單
     */
    grpIdList: function() {
      return [
        this.selectedSection ||
          this.selectedCenter ||
          this.selectedDistrict ||
          this.selectedDepartment ||
          this.selectedDivision ||
          this.selectedAdminDivision ||
          this.selectedRootGrpId
      ];
    },
    /**
     * 最小選中層級組織/群組代碼
     */
    organizationId: function() {
      return (
        this.selectedSection ||
        this.selectedCenter ||
        this.selectedDistrict ||
        this.selectedDepartment ||
        this.selectedDivision ||
        this.selectedAdminDivision
      );
    },
    /**
     * props帶入最小組織/群組代碼
     */
    leafPropsGrpId: function() {
      return (
        this.sectionId ||
        this.centerId ||
        this.districtId ||
        this.departmentId ||
        this.divisionId ||
        this.adminDivisionId ||
        this.rootGrpId
      );
    },
    /**
     * 總處Label
     */
    adminDivisionLabel: function() {
      return this.isShowLabel ? "總處單位" : "";
    },
    /**
     * 事業處Label
     */
    divisionLabel: function() {
      return this.isShowLabel ? "處級單位" : "";
    },
    /**
     * 部門Label
     */
    departmentLabel: function() {
      return this.isShowLabel ? "部級單位" : "";
    },
    /**
     * 分區Label
     */
    districtLabel: function() {
      return this.isShowLabel ? "區級單位" : "";
    },
    /**
     * 中心/分行Label
     */
    centerLabel: function() {
      return this.isShowLabel ? "中心/分行單位" : "";
    },
    /**
     * 科組Label
     */
    sectionLabel: function() {
      return this.isShowLabel ? "科組單位" : "";
    },
    /**
     * 人員Label
     */
    userLabel: function() {
      return this.isShowLabel ? "人員" : "";
    }
  },
  methods: {
    /**
     * 總處級單位異動處理器
     */
    onAdminDivisionChangeHandler: function() {
      this.selectedDivision = ""; // 處級
      this.selectedDepartment = ""; // 部級
      this.selectedDistrict = ""; // 區級
      this.selectedCenter = ""; // 中心/分行
      this.selectedSection = ""; // 科組
      this.selectedUser = ""; // 人員
    },
    /**
     * 處級單位異動處理器
     */
    onDivisionChangeHandler: function() {
      this.selectedDepartment = ""; // 部級
      this.selectedDistrict = ""; // 區級
      this.selectedCenter = ""; // 中心/分行
      this.selectedSection = ""; // 科組
      this.selectedUser = ""; // 人員
    },
    /**
     * 部級單位異動處理器
     */
    onDepartmentChangeHandler: function() {
      this.selectedDistrict = ""; // 區級
      this.selectedCenter = ""; // 中心/分行
      this.selectedSection = ""; // 科組
      this.selectedUser = ""; // 人員
    },
    /**
     * 區級單位異動處理器
     */
    onDistrictChangeHandler: function() {
      this.selectedCenter = ""; // 中心/分行
      this.selectedSection = ""; // 科組
      this.selectedUser = ""; // 人員
    },
    /**
     * 中心/分行單位異動處理器
     */
    onCenterChangeHandler: function() {
      this.selectedSection = ""; // 科組
      this.selectedUser = ""; // 人員
    },
    /**
     * 科組單位異動處理器
     */
    onSectionChangeHandler: function() {
      this.selectedUser = ""; // 人員
    }
  },
  watch: {
    /**
     * 監聽總處級單位
     */
    selectedAdminDivision: function() {
      this.$emit("on-admin-division-change", this.selectedAdminDivision);
      this.$emit("update:adminDivisionId", this.selectedAdminDivision);
    },
    /**
     * 監聽處級單位
     */
    selectedDivision: function() {
      this.$emit("on-division-change", this.selectedDivision);
      this.$emit("update:divisionId", this.selectedDivision);
    },
    /**
     * 監聽部級單位
     */
    selectedDepartment: function() {
      this.$emit("on-department-change", this.selectedDepartment);
      this.$emit("update:departmentId", this.selectedDepartment);
    },
    /**
     * 監聽區級單位
     */
    selectedDistrict: function() {
      this.$emit("on-district-change", this.selectedDistrict);
      this.$emit("update:districtId", this.selectedDistrict);
    },
    /**
     * 監聽中心/分行單位
     */
    selectedCenter: function() {
      this.$emit("on-center-change", this.selectedCenter);
      this.$emit("update:centerId", this.selectedCenter);
    },
    /**
     * 監聽科組單位
     */
    selectedSection: function() {
      this.$emit("on-section-change", this.selectedSection);
      this.$emit("update:sectionId", this.selectedSection);
    },
    /**
     * 監聽最小選中層級組織/群組代碼
     */
    organizationId: function() {
      this.$emit("on-org-change", this.organizationId);
      this.$emit("update:organizationId", this.organizationId);
    },
    /**
     * 監聽使用者
     */
    selectedUser: function() {
      this.$emit("on-user-change", this.selectedUser);
      this.$emit("update:userId", this.selectedUser);
    }
  },
  beforeCreate() {},
  async created() {
    // 查詢上層組織/群組清單 --------------------------------------------------------------------------------------------
    let upperUnits = await departmentApi.doQryUpperUnits({
      grpId: this.leafPropsGrpId,
      activatedGrp: this.activatedGrp
    });

    // 總處級單位 -------------------------------------------------------------------------------------------------------
    this.selectedAdminDivision =
      this._.find(upperUnits, row => {
        return "L50" === row.grpUnitcode; // L50: 總處級單位
      })?.grpId || "";

    // 處級單位 ---------------------------------------------------------------------------------------------------------
    this.selectedDivision =
      this._.find(upperUnits, row => {
        return "L55" === row.grpUnitcode; // L55: 處級單位
      })?.grpId || "";

    // 部級單位 ---------------------------------------------------------------------------------------------------------
    this.selectedDepartment =
      this._.find(upperUnits, row => {
        return "L60" === row.grpUnitcode; // L60: 部級單位
      })?.grpId || "";

    // 區級單位 ---------------------------------------------------------------------------------------------------------
    this.selectedDistrict =
      this._.find(upperUnits, row => {
        return "L70" === row.grpUnitcode; // L70: 區級單位
      })?.grpId || "";

    // 中心/分行單位 ----------------------------------------------------------------------------------------------------
    this.selectedCenter =
      this._.find(upperUnits, row => {
        return "L80" === row.grpUnitcode; // L80: 中心/分行單位
      })?.grpId || "";

    // 科組單位 ---------------------------------------------------------------------------------------------------------
    this.selectedSection =
      this._.find(upperUnits, row => {
        return "L90" === row.grpUnitcode; // L90: 科組單位
      })?.grpId || "";

    this.selectedRootGrpId = this.rootGrpId;
    this.selectedUser = this.userId || ""; // 人員
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
