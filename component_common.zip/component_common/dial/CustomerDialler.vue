<template>
  <div>
    <div @click="doGetDialInfo" class="slotStyle">
      <slot></slot>
    </div>

    <Modal
      v-model="isVisible"
      width="60vh"
      class="esun-modal"
      :title="'系統撥號 ' + sysName"
    >
      <!-- 顧客資訊 -->
      <Row>
        <Col span="16">
          名稱：
          <Tooltip
            max-width="200"
            :content="customerName"
            placement="top"
            transfer
          >
            <span>{{ customerInfo }}</span>
          </Tooltip>
          {{ customerId }}
        </Col>
        <Col span="8">業務編號：{{ businessId }}</Col>
      </Row>

      <!-- 顧客電話頁籤 -->
      <Tabs type="card" v-model="tabsNm" class="margin-row">
        <!-- 基本資料 -->
        <TabPane label="基本資料" name="基本資料">
          <Row>
            <Col span="19" offset="5">
              <customer-phone-list
                :callingNumber="extension"
                :isDialable="isDialable"
                :phoneList="customerPhoneList"
                :customerId="customerId"
                :customerName="customerName"
                :customerSex="customerSex"
                :businessId="businessId"
                :srcFuncCode="srcFuncCode"
                :srcFuncName="funcNameInfo"
              ></customer-phone-list>
            </Col>
          </Row>
        </TabPane>

        <!-- 周邊系統 -->
        <TabPane :label="sysName" :name="sysName" v-if="isShowSysTab">
          <Row>
            <Col span="19" offset="5">
              <customer-phone-list
                :callingNumber="extension"
                :isDialable="isDialable"
                :phoneList="customerTelList"
                :customerId="customerId"
                :customerName="customerName"
                :customerSex="customerSex"
                :businessId="businessId"
                :srcFuncCode="srcFuncCode"
                :srcFuncName="funcNameInfo"
              ></customer-phone-list>
            </Col>
          </Row>
        </TabPane>

        <!-- 快速撥號 -->
        <TabPane label="快速撥號" name="快速撥號" v-if="isDialable">
          <Row>
            <Col span="10" offset="8" class="dialler-content">
              <dialler
                :callingNumber="extension"
                :calledId="customerId"
                :calledInfo="customerName"
                :srcFuncCode="srcFuncCode"
                :srcFuncName="funcNameInfo"
                :businessId="businessId"
              ></dialler>
            </Col>
          </Row>
        </TabPane>
      </Tabs>

      <Row class="margin-row">
        <Col span="24">
          <!-- 顧客通話紀錄 -->
          <Table :columns="columns" :data="dialRecordList">
            <template slot-scope="{ row }" slot="user">
              <info-card :adAccount="row.userId">
                {{ row.userNm + "(" + row.userNo + ")" }}
              </info-card>
            </template>
          </Table>
        </Col>
      </Row>

      <!-- Button -->
      <div slot="footer">
        <Button class="cus-btn-mid" type="info" size="large" @click="closeModal"
          >關閉
        </Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import isBlank from "is-blank";
import codeApi from "@api/core/code-api";
import sysDialApi from "@api/common/sys-dial-api";
import customerApi from "@api/common/customer-api";
import Dialler from "@components/common/dial/Dialler.vue";
import CustomerPhoneList from "@components/common/dial/CustomerPhoneList.vue";

export default {
  components: {
    Dialler,
    CustomerPhoneList
  },
  props: {
    // 是否顯示系統頁籤
    isShowSysTab: {
      type: Boolean,
      required: false,
      default: false
    },
    // 顧客撥號清單, isShowSysTab = true 才有效
    customerTelList: {
      type: Array,
      required: false,
      default: () => []
    },
    // 顧客ID
    customerId: {
      type: String,
      required: true
    },
    // 顧客類別, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=157
    customerType: {
      type: String,
      required: true
    },
    // 顧客姓名
    customerName: {
      type: String,
      required: false
    },
    // 顧客性別, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=159
    customerSex: {
      type: String,
      required: false
    },
    // 功能代碼
    srcFuncCode: {
      type: String,
      required: true
    },
    // 功能代碼名稱
    srcFuncName: {
      type: String,
      required: true
    },
    // 業務編號
    businessId: {
      type: String,
      required: false,
      default: ""
    }
  },
  data() {
    return {
      // 是否顯示周邊系統撥號modal
      isVisible: false,
      // tabs name
      tabsNm: "基本資料",
      // 使用者分機
      extension: "",
      // 是否允許使用者撥號
      isDialable: false,
      // 顧客性別名稱
      sexName: "",
      // 顧客電話清單
      customerPhoneList: [],
      // table header
      columns: [
        {
          title: "系統名稱",
          key: "sysNm"
        },
        {
          title: "撥號業務項目",
          key: "funcNm"
        },
        {
          title: "業務編號",
          key: "refProckey"
        },
        {
          title: "受話號碼",
          key: "calledNumber",
          maxWidth: 130
        },
        {
          title: "通話狀態",
          key: "callStatusNm",
          maxWidth: 100
        },
        {
          title: "通話時間",
          key: "callTime",
          maxWidth: 190
        },
        {
          title: "發話人員",
          slot: "user",
          maxWidth: 150
        }
      ],
      // 顧客撥號記錄清單
      dialRecordList: []
    };
  },
  computed: {
    ...mapGetters(["optUserProfile"]),
    /**
     * 系統名稱
     */
    sysName: function() {
      return this.optUserProfile.system.sysNm || "";
    },
    /**
     * 功能名稱資訊
     */
    funcNameInfo: function() {
      return this.srcFuncName + "(" + this.tabsNm + ")";
    },
    /**
     * 顧客短名稱
     */
    shortNm: function() {
      return this._.truncate(this.customerName, { length: 20, separator: " " });
    },
    /**
     * 顧客性別名稱
     */
    sexInfo: function() {
      return isBlank(this.sexName) ? "" : "(" + this.sexName + ")";
    },
    /**
     * 顧客資訊
     */
    customerInfo: function() {
      return this.shortNm + this.sexInfo;
    }
  },
  methods: {
    /**
     * 取得撥號相關資訊
     */
    doGetDialInfo: async function() {
      this.isVisible = true;

      if (isBlank(this.customerId)) {
        return;
      }

      // 1. 查詢顧客電話清單 -----------------------------------------------------------------------------------------------
      this.customerPhoneList = await customerApi.doQryCustomerPhones({
        customerId: this.customerId,
        customerType: this.customerType
      });

      // 2. 查詢行內使用者撥號資訊 -----------------------------------------------------------------------------------------
      let dialInfo = await sysDialApi.doGetEmployeeDialInfo();

      this.extension = dialInfo.extension || "****";
      this.isDialable = "Y" == dialInfo.isCreditCardMember; // Y: 是信用卡處人員

      // 3. 查詢顧客撥號紀錄 -----------------------------------------------------------------------------------------------
      let result = await sysDialApi.doQryCustomerDialHistory(this.customerId);
      this.dialRecordList = result.customerDialList;
    },
    /**
     * 關閉視窗
     */
    closeModal: function() {
      this.isVisible = false;
    }
  },
  watch: {
    /**
     * 監聽顧客性別
     */
    customerSex: {
      handler: async function() {
        if (!isBlank(this.customerSex)) {
          this.sexName = await codeApi.doGetCodeName(159, this.customerSex);
        }
      },
      immediate: true
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped>
.slotStyle {
  font-weight: bold;
  color: #45b29d;
}
.margin-row {
  margin-top: 15px;
}
.dialler-content {
  margin-top: 15px;
  margin-bottom: 15px;
}
</style>
