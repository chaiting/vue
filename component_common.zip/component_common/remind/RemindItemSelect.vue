<template>
  <FormItem
    :label="remindItemLabel"
    :prop="remindItemNm"
    :class="formItemClass"
  >
    <Select
      v-model="selectedItem"
      clearable
      filterable
      placeholder="請選擇事項"
      @on-change="$emit('update:value', $event)"
      @on-clear="$emit('update:value', $event)"
      :disabled="readonly"
    >
      <Option
        v-for="item in itemList"
        :value="item.itemSeqNo"
        :key="item.itemSeqNo"
        >{{ item.itemDescription }}</Option
      >
    </Select>
  </FormItem>
</template>

<script>
import isBlank from "is-blank";
import f050501Api from "@api/f05/f050501-api";

export default {
  components: {},
  props: {
    // 下拉選單選中的值
    value: {
      type: String,
      required: false
    },
    // 服務提醒子類, Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=326
    remindSubClassId: {
      type: String,
      required: false
    },
    // 服務提醒事項標籤
    remindItemLabel: {
      type: String,
      required: false,
      default: "事項"
    },
    // 服務提醒事項名稱
    remindItemNm: {
      type: String,
      required: false,
      default: "remindItemSeqNo"
    },
    // 是否唯讀
    readonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否限已上架(01|02), Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=27
    remindItemSuspend: {
      type: String,
      required: false
    },
    // 是否顯示esun-form border(該元件必須放置在esun-form裡頭才會生效)
    isShowEsunFormBorder: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data() {
    return {
      // 選中的服務提醒事項
      selectedItem: "",
      // 服務提醒事項清單
      itemList: []
    };
  },
  computed: {
    /**
     * 表單項目class
     */
    formItemClass: function() {
      return {
        "not-show-border": !this.isShowEsunFormBorder
      };
    }
  },
  methods: {
    /**
     * 查詢服務提醒事項描述清單
     */
    doQryRemindItemsDesc: async function() {
      this.itemList = [];

      if (isBlank(this.remindSubClassId)) {
        return;
      }

      this.itemList = await f050501Api.doQryRemindItemsDesc({
        remindSubClassId: this.remindSubClassId,
        itemStatus: this.remindItemSuspend
      });
    },
    /**
     * 若選單中存在父元件選值則改選中值, 不存在則清空父元件選值
     */
    doUpdRemindItemValue: async function() {
      await this.doQryRemindItemsDesc();

      let vm = this;
      vm.selectedItem = vm.value;
      if (!vm.selectedItem || vm.selectedItem.length < 1) {
        return;
      }

      let isExists = vm._.find(vm.itemList, function(o) {
        return vm._.includes(vm.selectedItem, o.itemSeqNo);
      });

      if (!isExists) {
        this.$emit("update:value", "");
      }
    }
  },
  watch: {
    /**
     * 監聽服務提醒子類
     */
    remindSubClassId: function() {
      this.doUpdRemindItemValue();
    },
    /**
     * 監聽是否停用
     */
    remindItemSuspend: function() {
      this.doUpdRemindItemValue();
    },
    /**
     * 監聽服務提醒事項
     */
    value: function() {
      this.selectedItem = this.value;
    }
  },
  beforeCreate() {},
  created() {
    this.doUpdRemindItemValue();
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
