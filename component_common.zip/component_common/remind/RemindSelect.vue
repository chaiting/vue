<template>
  <Row>
    <!-- 服務提醒大類 -->
    <Col :span="colSpan">
      <FormItem
        :label="remindClassLabel"
        :prop="remindClassNm"
        :class="formItemClass"
      >
        <sys-cd-select
          :ctId="325"
          :value.sync="selectedRemindClassId"
          :readonly="remindClassReadonly"
          :suspend="suspend"
          @update:value="onRemindClassChangeHandler"
          placeholder="請選擇大類"
        ></sys-cd-select>
      </FormItem>
    </Col>
    <!-- 服務提醒子類 -->
    <Col :span="colSpan" :offset="colOffset">
      <FormItem
        :label="remindSubClassLabel"
        :prop="remindSubClassNm"
        :class="formItemClass"
      >
        <sys-cd-select
          :ctId="326"
          :value.sync="selectedRemindSubClassId"
          :readonly="remindClassReadonly"
          :flag01="remindClassCd"
          :key="subClassKey"
          :suspend="suspend"
          @update:value="onRemindSubClassChangeHandler"
          placeholder="請選擇子類"
        ></sys-cd-select>
      </FormItem>
    </Col>
    <!-- 服務提醒事項 -->
    <Col v-show="showRemindItem" :span="itemColSpan" :offset="colOffset">
      <remind-item-select
        :remindItemSuspend="remindItemSuspend"
        :value.sync="selectedRemindItemId"
        :remindSubClassId="selectedRemindSubClassId"
        :readonly="remindItemReadonly"
        :isShowEsunFormBorder="isShowEsunFormBorder"
        :remindItemNm="remindItemNm"
      ></remind-item-select>
    </Col>
  </Row>
</template>

<script>
import RemindItemSelect from "@components/common/remind/RemindItemSelect.vue";

export default {
  components: {
    RemindItemSelect
  },
  props: {
    // 服務提醒大類代碼
    remindClassId: {
      type: String,
      required: false
    },
    // 服務提醒子類代碼
    remindSubClassId: {
      type: String,
      required: false
    },
    // 服務提醒事項代碼
    remindItemId: {
      type: String,
      required: false
    },
    // 顯示服務提醒事項
    showRemindItem: {
      type: Boolean,
      required: false,
      default: true
    },
    // 服務提醒大類子類是否唯讀
    remindClassReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 服務提醒事項代碼是否唯讀
    remindItemReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否限已停用之服務提醒大類子類, N: 限啟用, Y: 限停用, null: 全部
    suspend: {
      type: String,
      required: false,
      default: "N"
    },
    // 是否限已上架之服務提醒事項, 01: 限已上架, 02: 限已下架, null: 全部
    remindItemSuspend: {
      type: String,
      required: false,
      default: "01"
    },
    // 是否顯示esun-form border(該元件必須放置在esun-form裡頭才會生效)
    isShowEsunFormBorder: {
      type: Boolean,
      required: false,
      default: false
    },
    // 服務提醒大類子類的佔位格數，可選總計0〜24的整數，為0時，相當於display:none
    colSpan: {
      type: Number,
      required: false,
      default: 12
    },
    // 服務提醒事項的佔位格數，可選總計0〜24的整數，為0時，相當於display:none
    itemColSpan: {
      type: Number,
      required: false,
      default: 24
    },
    // 元件間的間距
    colOffset: {
      type: Number,
      required: false,
      default: 0
    },
    // 服務提醒大類Item名稱
    remindClassNm: {
      type: String,
      required: false,
      default: "remindClassId"
    },
    // 服務提醒子類Item名稱
    remindSubClassNm: {
      type: String,
      required: false,
      default: "remindSubClassId"
    },
    // 服務提醒事項Item名稱
    remindItemNm: {
      type: String,
      required: false,
      default: "remindItemSeqNo"
    },
    // 服務提醒大類Label
    remindClassLabel: {
      type: String,
      required: false,
      default: "提醒大類"
    },
    // 服務提醒子類Label
    remindSubClassLabel: {
      type: String,
      required: false,
      default: "提醒子類"
    }
  },
  data() {
    return {
      // 所選服務提醒大類代碼
      selectedRemindClassId: "",
      // 所選服務提醒子類代碼
      selectedRemindSubClassId: "",
      // 所選服務提醒事項代碼
      selectedRemindItemId: "",
      // 服務提醒子類代碼元件鍵值
      subClassKey: 0,
      // 服務提醒事項清單
      itemList: []
    };
  },
  computed: {
    /**
     * 服務提醒子類上層代碼
     */
    remindClassCd: function() {
      return this.selectedRemindClassId || "N/A";
    },
    /**
     * 表單項目class
     */
    formItemClass: function() {
      return {
        "not-show-border": !this.isShowEsunFormBorder
      };
    }
  },
  methods: {
    /**
     * 服務提醒大類異動處理
     */
    onRemindClassChangeHandler: function() {
      this.$emit("update:remindClassId", this.selectedRemindClassId);
    },
    /**
     * 服務提醒子類異動處理
     */
    onRemindSubClassChangeHandler: function() {
      this.$emit("update:remindSubClassId", this.selectedRemindSubClassId);
    },
    /**
     * 服務提醒事項異動處理
     */
    onRemindItemChangeHandler: function() {
      this.$emit("update:remindItemId", this.selectedRemindItemId);
    }
  },
  watch: {
    /**
     * 監聽服務提醒大類代碼
     */
    remindClassId: function() {
      this.selectedRemindClassId = this.remindClassId;
    },
    /**
     * 監聽服務提醒子類代碼
     */
    remindSubClassId: function() {
      this.selectedRemindSubClassId = this.remindSubClassId;
    },
    /**
     * 監聽服務提醒事項
     */
    remindItemId: function() {
      this.selectedRemindItemId = this.remindItemId;
    },
    /**
     * 監聽已選中服務提醒大類代碼
     */
    selectedRemindClassId: function() {
      this.subClassKey++;
      this.$emit("on-class-change", this.selectedRemindClassId);
      this.$emit("update:remindClassId", this.selectedRemindClassId);
    },
    /**
     * 監聽已選中服務提醒子類代碼
     */
    selectedRemindSubClassId: function() {
      this.$emit("on-subclass-change", this.selectedRemindSubClassId);
      this.$emit("update:remindSubClassId", this.selectedRemindSubClassId);
    },
    /**
     * 監聽已選中服務提醒事項代碼
     */
    selectedRemindItemId: function() {
      this.$emit("on-item-change", this.selectedRemindItemId);
      this.$emit("update:remindItemId", this.selectedRemindItemId);
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped>
.esun-form .ivu-form-item .ivu-select {
  margin: auto;
}
.esun-form
  .ivu-row
  .ivu-col-span-12
  + .ivu-col-span-12
  .ivu-form-item:not(.not-show-border) {
  border-right: 1px solid #cecece;
}
</style>
