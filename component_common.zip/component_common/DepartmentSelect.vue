<template>
  <Select
    v-model="selectedDept"
    clearable
    filterable
    :disabled="readonly"
    :multiple="multiple"
    :placeholder="placeholder"
    @on-change="$emit('update:value', $event)"
    @on-clear="$emit('update:value', $event)"
  >
    <Option v-for="dept in deptList" :value="dept.grpId" :key="dept.grpId">{{
      dept.grpNm
    }}</Option>
  </Select>
</template>

<script>
import isBlank from "is-blank";
import departmentApi from "@api/common/department-api";

export default {
  components: {},
  props: {
    // 選中的組織/群組清單
    value: {
      type: [String, Array],
      required: false
    },
    // 上層組織/群組代碼清單, Ref DATAASYNC.TB_GROUP.GRP_ID
    upGrpIdList: {
      type: Array,
      required: false
    },
    // 組織/群組層級代碼, Ref DATASHARE.SYS_CD.CD_ID, CT_ID=32
    grpUnitcode: {
      type: String,
      required: false
    },
    // 組織/群組資料來源, Ref DATASHARE.SYS_CD.CD_ID, CT_ID=29
    dataSrc: {
      type: String,
      required: false
    },
    // 是否限啟用組織/群組(Y|N)
    activatedGrp: {
      type: String,
      required: false,
      default: "Y",
      validator: function(value) {
        return ["", "Y", "N"].includes(value);
      }
    },
    // 是否包含所有子單位(Y|N)
    allSubordinate: {
      type: String,
      required: false,
      default: "N",
      validator: function(value) {
        return ["", "Y", "N"].includes(value);
      }
    },
    // 是否可多選
    multiple: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否唯讀
    readonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 選擇框默認文字
    placeholder: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      // 組織/群組清單
      deptList: [],
      // 選中的組織/群組清單
      selectedDept: []
    };
  },
  computed: {},
  methods: {
    /**
     * 查詢組織/群組清單
     */
    doQryDeptList: async function() {
      this.deptList = [];

      let depts =
        this._.filter(this.upGrpIdList, row => {
          return !isBlank(row);
        }) || [];

      if (depts.length < 1) {
        return;
      }

      this.deptList = await departmentApi.doQryDeptList({
        upGrpIdList: depts,
        grpUnitcode: this.grpUnitcode,
        dataSrc: this.dataSrc,
        activatedGrp: this.activatedGrp,
        allSubordinate: this.allSubordinate
      });
    },
    /**
     * 若選單中存在父元件選值則改選中值, 不存在則清空父元件選值
     */
    doUpdateSelectedValue: async function() {
      await this.doQryDeptList();

      let vm = this;
      vm.selectedDept = vm.value;

      if (!vm.selectedDept || vm.selectedDept.length < 1) {
        return;
      }

      let isExists = vm._.find(vm.deptList, function(o) {
        return vm._.includes(vm.selectedDept, o.grpId);
      });

      if (!isExists) {
        this.$emit("update:value", null);
      }
    }
  },
  watch: {
    /**
     * 監聽上層組織/群組代碼清單, Ref DATAASYNC.TB_GROUP.GRP_ID
     */
    upGrpIdList: {
      handler: function() {
        this.doUpdateSelectedValue();
      },
      deep: true
    },
    /**
     * 監聽是否限啟用組織/群組(Y|N)
     */
    activatedGrp: function() {
      this.doUpdateSelectedValue();
    }
  },
  beforeCreate() {},
  created() {
    this.doUpdateSelectedValue();
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
