<template>
  <div>
    <Row>
      <!-- 縣市 -->
      <Col :span="colSpan">
        <FormItem
          :label="cityLabel"
          :prop="cityItemNm"
          :class="formItemClass"
          half
        >
          <sys-cd-select
            :ctId="8"
            :value.sync="selectedCityCd"
            :readonly="cityReadonly"
            :suspend="suspend"
            placeholder="請選擇縣市"
            @update:value="onCityChangeHandler"
          ></sys-cd-select>
        </FormItem>
      </Col>
      <!-- 鄉鎮市區 -->
      <Col :span="colSpan" :offset="colOffset">
        <FormItem
          :label="postalLabel"
          :prop="postalItemNm"
          :class="formItemClass"
          half
        >
          <sys-cd-select
            :ctId="9"
            :value.sync="selectedPostalCd"
            :readonly="postalReadonly"
            :flag01="postalParentCd"
            :key="postalKey"
            :suspend="suspend"
            placeholder="請選擇鄉鎮市區"
          ></sys-cd-select>
        </FormItem>
      </Col>
    </Row>
  </div>
</template>

<script>
import isBlank from "is-blank";
import codeApi from "@api/core/code-api";

export default {
  components: {},
  props: {
    // 縣市代碼
    cityCd: {
      type: String,
      required: false
    },
    // 鄉鎮市區代碼
    postalCd: {
      type: String,
      required: false
    },
    // 縣市代碼是否唯讀
    cityReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 鄉鎮市區代碼是否唯讀
    postalReadonly: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否限已停用之縣市郵區, Y: 限停用, N: 限啟用, null: 全部
    suspend: {
      type: String,
      required: false
    },
    // Label是否顯示
    isShowLabel: {
      type: Boolean,
      required: false,
      default: false
    },
    // 是否顯示esun-form border(該元件必須放置在esun-form裡頭才會生效)
    isShowEsunFormBorder: {
      type: Boolean,
      required: false,
      default: false
    },
    // 上方的佔位格數，可選總計0〜24的整數，為0時，相當於display:none
    colSpan: {
      type: Number,
      required: false,
      default: 11
    },
    // 元件間的間距
    colOffset: {
      type: Number,
      required: false,
      default: 2
    },
    // 縣市表單Item名稱
    cityItemNm: {
      type: String,
      required: false,
      default: "cityCd"
    },
    // 鄉鎮市區表單Item名稱
    postalItemNm: {
      type: String,
      required: false,
      default: "postalCd"
    }
  },
  data() {
    return {
      // 所選縣市代碼
      selectedCityCd: "",
      // 所選鄉鎮市區代碼
      selectedPostalCd: "",
      // 鄉鎮市區代碼元件鍵值
      postalKey: 0
    };
  },
  computed: {
    /**
     * 縣市Label
     */
    cityLabel: function() {
      return this.isShowLabel ? "縣市" : "";
    },
    /**
     * 鄉鎮市區Label
     */
    postalLabel: function() {
      return this.isShowLabel ? "鄉鎮市區" : "";
    },
    /**
     * 鄉鎮市區上層縣市代碼
     */
    postalParentCd: function() {
      return this.selectedCityCd || "N/A";
    },
    /**
     * 表單項目class
     */
    formItemClass: function() {
      return {
        "not-show-border": !this.isShowEsunFormBorder,
        "not-show-label": !this.isShowLabel
      };
    }
  },
  methods: {
    /**
     * 縣市異動處理
     */
    onCityChangeHandler: function() {
      this.selectedPostalCd = "";
    }
  },
  watch: {
    /**
     * 監聽縣市代碼
     */
    cityCd: {
      immediate: true,
      handler(newValue) {
        this.selectedCityCd = newValue;
      }
    },
    /**
     * 監聽鄉鎮市區代碼
     */
    postalCd: {
      immediate: true,
      async handler(newValue) {
        this.selectedPostalCd = newValue;

        if (isBlank(newValue)) {
          return;
        }

        // 1. 查詢縣市別代碼 ----------------------------------------------------------------------------------------------
        let codeUnits = await codeApi.doQryCodeList({
          ctId: "9", // 9: 鄉政區
          cdId: newValue
        });

        this.selectedCityCd = codeUnits.data.body[0]?.flag01 || "";

        // 2. 設定鄉鎮市區代碼 --------------------------------------------------------------------------------------------
        this.$nextTick(function() {
          this.selectedPostalCd = newValue;
        });
      }
    },
    /**
     * 監聽已選中縣市代碼
     */
    selectedCityCd: function() {
      this.postalKey++;

      this.$emit("on-city-change", this.selectedCityCd);
      this.$emit("update:cityCd", this.selectedCityCd);
    },
    /**
     * 監聽已選中鄉鎮市區代碼
     */
    selectedPostalCd: function() {
      this.$emit("on-postal-change", this.selectedPostalCd);
      this.$emit("update:postalCd", this.selectedPostalCd);
    }
  },
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
