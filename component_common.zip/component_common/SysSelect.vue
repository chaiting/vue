<template>
  <Select
    v-model="selectedItems"
    filterable
    clearable
    :placeholder="placeholder"
    @on-change="$emit('update:value', $event)"
    @on-clear="$emit('update:value', $event)"
  >
    <Option v-for="item in items" :value="item.value" :key="item.value">{{
      item.label
    }}</Option>
  </Select>
</template>

<script>
import systemApi from "@api/common/system-api";

export default {
  components: {},
  props: {
    // 下拉選單選中的值
    value: {
      type: String,
      required: false
    },
    // 選擇框默認文字
    placeholder: {
      type: String,
      required: false
    },
    // 系統狀態(A|I), Ref DATASHARE.TB_SYS_CD.CD_ID, CT_ID=30
    status: {
      type: String,
      required: false
    }
  },
  data() {
    return {
      items: [],
      selectedItems: []
    };
  },
  computed: {},
  methods: {
    /**
     * 取得下拉選單選項清單
     */
    doQrySysLabelValueList: async function() {
      this.items = await systemApi.doQrySysLabelValueList({
        sysSts: this.status
      });
    },
    /**
     * 若選單中存在父元件選值則改選中值, 不存在則清空父元件選值
     * @param payload 執行參數
     */
    doUpdateSelectedValue: async function(payload) {
      // Y: 強制重載
      if ("Y" === payload.forceReload || this.items.length < 1) {
        await this.doQrySysLabelValueList();
      }

      let vm = this;
      vm.selectedItems = vm.value;
      if (!vm.selectedItems || vm.selectedItems.length < 1) {
        return;
      }

      let isExists = vm._.find(vm.items, function(o) {
        return vm._.includes(vm.selectedItems, o.value);
      });

      if (!isExists) {
        this.$emit("update:value", null);
      }
    }
  },
  watch: {
    // 選項值
    value: function() {
      this.doUpdateSelectedValue({
        forceReload: "N" // N: 不強制重載
      });
    },
    // 是否停用
    suspend: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    }
  },
  beforeCreate() {},
  created() {
    this.doUpdateSelectedValue({
      forceReload: "Y" // Y: 強制重載
    });
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
