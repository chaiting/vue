<template>
  <Select
    :element-id="elementId"
    v-model="selectedItems"
    filterable
    :clearable="clearable"
    :placeholder="placeholder"
    :multiple="multiple"
    :transfer="transfer"
    :disabled="readonly"
    :max-tag-count="maxTagCount"
    @on-change="onChangeHandler"
    @on-clear="onChangeHandler"
  >
    <Option v-for="item in items" :value="item.value" :key="item.value">{{
      item.label
    }}</Option>
  </Select>
</template>

<script>
import codeApi from "@api/core/code-api";

export default {
  components: {},
  props: {
    // 下拉選單選中的值
    value: {
      type: [String, Array]
    },
    // 選擇框默認文字
    placeholder: {
      type: String
    },
    // 是否可多選
    multiple: {
      type: Boolean,
      required: false
    },
    // 是否將彈層放置於body 內
    transfer: {
      type: Boolean,
      default: false
    },
    // 是否唯讀
    readonly: {
      type: Boolean,
      default: false
    },
    // 多選時最多顯示幾個
    maxTagCount: {
      type: Number
    },
    // 選項是否顯示明細代碼
    showCode: {
      type: Boolean,
      default: false
    },
    // 元件ID
    elementId: {
      type: String
    },
    // 類別代碼
    ctId: {
      type: Number,
      required: true
    },
    // 明細代碼
    cdId: {
      type: String
    },
    // 是否停用
    suspend: {
      type: String
    },
    // 其它用途註記 01
    flag01: {
      type: String
    },
    // 其它用途註記 02
    flag02: {
      type: String
    },
    // 其它用途註記 03
    flag03: {
      type: String
    },
    // 其它用途註記 04
    flag04: {
      type: String
    },
    // 其它用途註記 05
    flag05: {
      type: String
    },
    // 其它用途註記 06
    flag06: {
      type: String
    },
    // 其它用途註記 07
    flag07: {
      type: String
    },
    // 其它用途註記 08
    flag08: {
      type: String
    },
    // 其它用途註記 09
    flag09: {
      type: String
    },
    // 其它用途註記 10
    flag10: {
      type: String
    }
  },
  model: {
    prop: "value",
    event: "update"
  },
  data() {
    return {
      items: [],
      selectedItems: []
    };
  },
  computed: {
    clearable: function() {
      return !this.readonly;
    }
  },
  methods: {
    /**
     * 選項異動處理
     */
    onChangeHandler: function($event) {
      this.$emit("update:value", $event);
      this.$emit("update", $event);
    },
    /**
     * 取得下拉選單選項清單
     */
    doQryCodeLabelValueList: async function() {
      this.items = await codeApi.doQryCodeLabelValueList({
        ctId: this.ctId,
        cdId: this.cdId,
        showCode: this.showCode,
        suspend: this.suspend,
        flag01: this.flag01,
        flag02: this.flag02,
        flag03: this.flag03,
        flag04: this.flag04,
        flag05: this.flag05,
        flag06: this.flag06,
        flag07: this.flag07,
        flag08: this.flag08,
        flag09: this.flag09,
        flag10: this.flag10
      });
    },
    /**
     * 若選單中存在父元件選值則改選中值, 不存在則清空父元件選值
     * @param payload 執行參數
     */
    doUpdateSelectedValue: async function(payload) {
      // Y: 強制重載
      if ("Y" === payload.forceReload || this.items.length < 1) {
        await this.doQryCodeLabelValueList();
      }

      let vm = this;
      vm.selectedItems = vm.value;
      if (!vm.selectedItems || vm.selectedItems.length < 1) {
        return;
      }

      let isExists = vm._.find(vm.items, function(o) {
        return vm._.includes(vm.selectedItems, o.value);
      });

      if (!isExists) {
        this.$emit("update:value", null);
        this.$emit("update", null);
      }
    }
  },
  watch: {
    // 選項值
    value: function() {
      this.doUpdateSelectedValue({
        forceReload: "N" // N: 不強制重載
      });
    },
    // 是否停用
    suspend: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    /**
     * 類別代碼
     */
    ctId: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 01
    flag01: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 02
    flag02: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 03
    flag03: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 04
    flag04: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 05
    flag05: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 06
    flag06: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 07
    flag07: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 08
    flag08: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 09
    flag09: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    },
    // 其它用途註記 10
    flag10: function() {
      this.doUpdateSelectedValue({
        forceReload: "Y" // Y: 強制重載
      });
    }
  },
  beforeCreate() {},
  created() {
    this.doUpdateSelectedValue({
      forceReload: "Y" // Y: 強制重載
    });
  },
  beforeMount() {},
  mounted() {},
  activated() {},
  deactivated() {},
  beforeUpdate() {},
  updated() {},
  beforeDestroy() {},
  destroyed() {}
};
</script>

<style lang="scss" scoped></style>
